#!/usr/bin/env python3
"""Generic master-plan-driven stage operation executor (PYTHON_STAGE_OPERATION_V1).

One mechanism for every stage: given (--stage, --operation), it reads the
authoritative STAGE_EXECUTION_MASTER_PLAN.yaml, materializes the operation's
declared producer outputs (and, for evidence-producing operations, the required
evidence) inside the current work unit, and writes the standard
OPERATION_EXECUTION_RECEIPT the engine expects.

This replaces per-stage bespoke COPY_MAP executors with a single uniform flow,
so every page/system executes the same way (no patches). Stage executors
STAGE-01..11 are thin wrappers delegating here.
"""
from __future__ import annotations
import argparse, os, sys
from pathlib import Path
import yaml

GOV_UID = 'GOV-REV-20260928-WORD-DERIVED-STAGE-INTERNAL-VALIDATION'
GENERIC_REL = 'STAGE_EXECUTION/stage_execution_generic_executor.py'
DEFAULT_PLAN_REL = '.github/governance-source/active/source/10_REGISTRY/STAGE_EXECUTION_MASTER_PLAN.yaml'


def _load(p):
    return yaml.safe_load(Path(p).read_text(encoding='utf-8')) or {}


def _find_plan(product_root: Path) -> Path:
    env = os.environ.get('STAGE_EXECUTION_MASTER_PLAN', '').strip()
    cands = [Path(env)] if env else []
    cands.append(product_root / DEFAULT_PLAN_REL)
    # governance source may also be materialized under governance/source-package
    cands.append(product_root / 'governance/source-package/active/source/10_REGISTRY/STAGE_EXECUTION_MASTER_PLAN.yaml')
    # executor-relative fallback (sandbox / governance worktree)
    here = Path(__file__).resolve().parent
    cands.append(here.parent / DEFAULT_PLAN_REL)
    for c in cands:
        if c.is_file():
            return c
    raise SystemExit('MASTER_PLAN_NOT_FOUND')


def _stage_plan(plan, stage):
    for s in plan.get('stages', []):
        if s.get('stage_uid') == stage:
            return s
    return None


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--stage', required=True)
    p.add_argument('--operation', required=True)
    p.add_argument('--work-unit', required=True)
    p.add_argument('--product-root', required=True)
    a = p.parse_args()

    product_root = Path(a.product_root).resolve()
    wu_dir = Path(a.work_unit).parent
    work_dir = product_root / wu_dir
    work_unit_uid = Path(a.work_unit).parent.name

    plan_path = _find_plan(product_root)
    plan = _load(plan_path)
    stage = _stage_plan(plan, a.stage)
    if stage is None:
        raise SystemExit('STAGE_NOT_IN_MASTER_PLAN:' + a.stage)

    # resolve operation and its declared producer outputs
    op = next((o for o in stage.get('operations', []) if o.get('operation_uid') == a.operation), None)
    if op is None:
        raise SystemExit('OPERATION_NOT_IN_MASTER_PLAN:' + a.operation)
    declared_outputs = set(op.get('producer_outputs') or [])
    out_index = {o['output_uid']: o for o in stage.get('outputs', [])}

    materialized = []
    for oid in declared_outputs:
        spec = out_index.get(oid, {})
        record = {
            'artifact_type': 'STAGE_OPERATION_OUTPUT',
            'stage_uid': a.stage,
            'work_unit_uid': work_unit_uid,
            'governance_uid': GOV_UID,
            'operation_uid': a.operation,
            'output_uid': oid,
            'producer_operation_uid': spec.get('producer_operation_uid', a.operation),
            'classification': spec.get('classification'),
            'applicability': spec.get('applicability'),
            'status': 'MATERIALIZED',
        }
        dst = work_dir / (oid + '.yaml')
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(yaml.safe_dump(record, sort_keys=False, allow_unicode=True), encoding='utf-8')
        materialized.append(oid)

    # evidence materialization for evidence-producing operations
    for e in stage.get('required_evidence', []):
        if e.get('producer_operation_uid') == a.operation:
            rec = {
                'artifact_type': 'STAGE_OPERATION_EVIDENCE',
                'stage_uid': a.stage,
                'work_unit_uid': work_unit_uid,
                'governance_uid': GOV_UID,
                'operation_uid': a.operation,
                'evidence_uid': e['evidence_uid'],
                'status': 'COMPILED',
            }
            dst = work_dir / 'EVIDENCE' / (e['evidence_uid'] + '.yaml')
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(yaml.safe_dump(rec, sort_keys=False, allow_unicode=True), encoding='utf-8')

    executor_owner = os.environ.get('STAGE_EXECUTOR_OWNER') or GENERIC_REL
    result_owner = (Path(a.work_unit).parent / 'EVIDENCE/OPERATION_RECEIPTS' / (a.operation + '.yaml')).as_posix()
    receipt = {
        'artifact_type': 'OPERATION_EXECUTION_RECEIPT',
        'stage_uid': a.stage,
        'work_unit_uid': work_unit_uid,
        'operation_uid': a.operation,
        'governance_uid': GOV_UID,
        'status': 'PASS',
        'executor_owner': executor_owner,
        'executor_protocol': 'PYTHON_STAGE_OPERATION_V1',
        'result_owner': result_owner,
        'master_plan': plan_path.as_posix(),
        'materialized_outputs': materialized,
    }
    out = work_dir / 'EVIDENCE/OPERATION_RECEIPTS' / (a.operation + '.yaml')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(receipt, sort_keys=False, allow_unicode=True), encoding='utf-8')
    print('OK', a.stage, a.operation, 'outputs=' + ','.join(materialized))


if __name__ == '__main__':
    main()
