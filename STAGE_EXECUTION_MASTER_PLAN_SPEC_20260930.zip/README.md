# STAGE 完整規範封裝包（STAGE_EXECUTION_MASTER_PLAN）

- 封裝日期：2026-09-30
- 治理分支：`rebuild-v2.1.1`（worktree `/tmp/opencode/rebuild-v2.1.1`，HEAD `f5284108`）
- 規範版本：`governance_revision = v2.2.34-word-derived-stage-internal-validation-20260928`
- 權威產物 UID：`REG-STAGE-EXECUTION-MASTER-PLAN-001`
- 權威模式：`authority_mode = EXECUTION_PROJECTION_ONLY`、`may_create_new_normative_requirement = false`

## 內容

| 目錄 | 檔案 | 說明 |
|------|------|------|
| `01_NORMATIVE/` | `STAGE_EXECUTION_MASTER_PLAN.yaml` | 唯一權威全線規範：STAGE-01..11 的操作／產物／生產者／必要證據／必要章節／驗證器／掃描維度／交接／上線就緒。 |
| `02_VALIDATORS/` | `validate_stage_execution_master_plan.py` | 主計畫驗證器（C-A..C-I，fail-closed）。 |
| | `test_stage_execution_master_plan.py` | 回歸測試（6 案，含注入缺陷 fail-closed）。 |
| | `validate_stage_execution_invariants.py` | STAGE invariant 驗證器（VAL-GOV-035，69 條）。 |
| `03_ENGINE/` | `stage_execution_engine.py` | 執行引擎（含 `validate_master_plan`，於 `--definition-audit-all` 定義期串接）。 |
| `04_REGISTRY/` | `REGISTRY.yaml` | 治理入口（`stage_execution_master_plan` 綁定 + 兩條 validation command）。 |
| `05_SOURCE_CHECKSUMS/` | `CHECKSUMS.sha256` | 治理來源包校驗台帳（68 rows）。 |
| `06_SPEC/` | `requirements.md`、`design.md`、`defect-register.md`、`sandbox-report.md`、`page-run-report.md`、`full-flow-report.md` | 需求、設計、缺陷登錄、各階段沙盤／全流程報告。 |
| `07_PAGE_RUN/` | `page_global_home.yaml`、`page_run.py`、`page_run_result.json` | 頁面完整性沙盤（STAGE-01..11）。 |
| `08_FULL_FLOW/` | `run_full_flow.py`、`full_flow_result.json`、`run_out/` | 通用主計畫驅動 runner，完整跑完 11 站至線上；`run_out` 為逐站產物樹。 |
| `09_EXECUTORS/` | `stage_execution_generic_executor.py`、`stages/`、`run_executors.py`、`executor_drive_result.json` | STAGE-05..11 執行器（單一通用機制 + 薄包裝），及 11 站 121 操作的驅動結果。 |

## 結果摘要

- **頁面完整性沙盤**：`GLOBAL-HOME-SHELL-NAVIGATION` → `verdict = PASS`（9/9 responsibilities、5/5 functional chains、6/6 entities）。反向注入測試 → `FAIL`（fail-closed）。
- **全流程 runner**：→ `verdict = ONLINE_READY`（11 站、63 產物、13 證據、0 blocker；上線於 `STAGE-09`，關閉於 `STAGE-11`）。
- **執行器驅動**：`STAGE-01..11` 共 **121 操作全數 PASS**，各產生 `OPERATION_EXECUTION_RECEIPT`（協定 `PYTHON_STAGE_OPERATION_V1`）。

## 先前無法跑完的原因與調整

- `STAGE_EXECUTION/` 原本只有 `STAGE-01..04` 的執行器；`STAGE-05..11` 無執行器。
- `STAGE-05` 的複合 `entry_gate` 與 `STAGE-04` 的 `exit_gate` 字面不同，字串全等比對會阻擋。
- 調整：改為**單一通用、主計畫驅動**的執行器／runner；閘門採 **equal-or-stricter** 語意（與引擎 `SUCCESSOR_GATE_MISMATCH` 規則一致）；條件式操作依頁面特徵求值。

## 驗證狀態（於 `rebuild-v2.1.1` worktree）

全部 PASS：

- `python governance/ci/stage_execution_engine.py --definition-audit-all`
- `python .github/governance-source/active/source/09_TESTS/governance/validate_stage_execution_master_plan.py`
- `python .github/governance-source/active/source/09_TESTS/governance/test_stage_execution_master_plan.py`
- `python .github/governance-source/active/source/09_TESTS/governance/validate_stage_execution_invariants.py`
- `python governance/ci/validate_current_source_package.py`
- `python governance/ci/validate_governance_layout.py`
- `python governance/ci/validate_selected_execution_profile_integrity.py`
- `python governance/ci/validate_active_consumer_reference_integrity.py`
- `python governance/ci/validate_successor_governance_preformal.py`

## 不變量

- 計畫為唯一權威，生命週期登錄與語意適配器為其投影。
- 所有受治理單元使用同一固定建構信封；`page_specific_schema_variation: FORBIDDEN`。
- 主計畫不得新增規範性需求，只能投影既有權威宣告。
- 錯誤碼：`MASTER_PLAN_PROJECTION_DRIFT`、`MASTER_PLAN_DANGLING_PRODUCER`、`MASTER_PLAN_EVIDENCE_PRODUCER_INVALID`、`MASTER_PLAN_HANDOFF_STAGE_DRIFT`、`MASTER_PLAN_ORPHAN_INVARIANT_UNBOUND` 等，於定義期終止。

## 如何重跑

沙盤器需讀取治理來源樹（`STAGE_EXECUTION_MASTER_PLAN.yaml` 等）。於含治理來源的環境執行：

```bash
# 頁面完整性沙盤
python3 07_PAGE_RUN/page_run.py

# 通用全流程 runner（STAGE-01..11 至線上）
python3 08_FULL_FLOW/run_full_flow.py

# 驅動 11 站執行器（需先將 09_EXECUTORS 內容放回 STAGE_EXECUTION/）
python3 09_EXECUTORS/run_executors.py
```

腳本預設讀取絕對路徑；移植時請調整檔頭常數。

## 限制

- 本執行為沙盤（tabletop）：不產生 effectful 產物、不呼叫外部系統、不消耗 completion credit。
- `STAGE-05..11` 執行器為**通用協定執行器**（依主計畫物化宣告輸出 + 產生 receipt）；真實 build/staging/production 內容仍須於實際執行環境由對應工具產生。
