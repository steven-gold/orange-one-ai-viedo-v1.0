#!/usr/bin/env python3
from __future__ import annotations
import copy, hashlib, io, json, lzma, os, re, subprocess, sys, tarfile, zipfile
from pathlib import Path
import yaml

ROOT = Path(os.environ.get('GITHUB_WORKSPACE', '.')).resolve()
SOURCE = ROOT / '.github/governance-source/active/source'
OLD_UID = 'GOV-REV-20260919-BLUEPRINT-CONSTRUCTION-TRACEABILITY-HARDENING'
NEW_UID = 'GOV-REV-20260919-BASIC-DESIGN-VISUAL-INTEGRATION-HARDENING'
OLD_DISPLAY = 'v2.2.10'
NEW_DISPLAY = 'v2.2.11'
OLD_SOURCE_REV = 'v2.2.10-blueprint-construction-traceability-hardening'
NEW_SOURCE_REV = 'v2.2.11-basic-design-visual-integration-hardening'
AUTH_UID = 'USR-DIRECTIVE-20260919-BASIC-DESIGN-VISUAL-INTEGRATION-R1'
WORK_UNIT = 'WU-GOV-BASIC-DESIGN-VISUAL-INTEGRATION-001'
NEW_PACKAGE = 'AI_WEB_GOVERNANCE_FULL_LIFECYCLE_v2.2.11_BASIC_DESIGN_VISUAL_INTEGRATION_LOCAL_VERIFIED.zip'

SECTIONS = {
'WEB-GOV-01-S076': ('76','基本設計包完整度 Gate / Basic Design Package Completeness', r'''Every governed product/system scope MUST materialize one complete `BASIC_DESIGN_PACKAGE` before Basic Design Freeze. The package is a design-domain artifact and MUST be complete independently of downstream implementation, code construction, runtime verification, deployment, or production acceptance.

The applicable Basic Design Package MUST contain, or bind by exact UID/hash to, at least:

1. Scope, Business Goal, Target Users/Roles, Functional/Non-functional Requirements, Out-of-Scope, Glossary, and Naming intent.
2. System/Module/Dependency/Navigation/User Flow/Business Flow/State/Data/Boundary architecture.
3. Business Entity Inventory, Business Entity Operation Matrix, and Entity Hierarchy Matrix.
4. User Journey Registry, Functional Workbench Contract, Interaction Topology, and conditional AI Interaction Continuity when applicable.
5. Page/Surface information architecture, Sections, Components, Controls, Fields, states, permissions/gates at design semantics, and cross-page design relationships when applicable.
6. Visual Architecture, Layout/Grid, responsive semantic order, accessibility focus intent, and all required visual anchors.
7. `VISUAL_INHERITANCE_MATRIX` and `VISUAL_STYLE_DEFINITION` resolving inherited Current visual authorities or defining a new complete project visual system when none exists.
8. Functional-Visual Bidirectional Traceability and Scenario-to-Function Visual Coverage.
9. Required high-fidelity Visual Candidates for all applicable states/scenarios and their Visual Reference Annotations.
10. Human-readable Basic Design deliverable with required figures embedded in context.
11. Design review state, unresolved design gaps, approved change sets, and Basic Design Freeze status.

Each item MUST declare `REQUIRED`, `OPTIONAL`, or `NOT_APPLICABLE`; `NOT_APPLICABLE` requires design/authority evidence. A missing applicable item is `BASIC_DESIGN_PACKAGE_INCOMPLETE` and MUST block Basic Design Freeze.

Basic Design completion MUST_NOT require `CONSTRUCTION_DELTA_MATRIX`, source-code audit, implementation manifest, runtime test evidence, deployment evidence, production evidence, or implementation handoff. Those belong to later, independent lifecycle standards.'''),
'WEB-GOV-01-S077': ('77','功能與視覺雙向追溯 Gate / Functional-Visual Bidirectional Traceability', r'''Every user-visible or user-observable REQUIRED function in Basic Design MUST resolve the exact forward design trace:

`Business Entity -> Operation -> Journey -> Functional Workbench -> Section -> Component -> Control/System Trigger -> Field/Input -> State -> Visual Anchor -> Visual Candidate -> Design Review Item`.

The reverse trace is also REQUIRED for every visible interactive or state-bearing visual element. Each Card, Panel, Tab, Button, Input, Selector, Badge, Drawer, Modal, Timeline, Conversation Surface, State Rail, Status Strip, and equivalent element MUST resolve backward to one governed Business Entity operation or registered non-entity utility operation.

A visible element without backward ownership is `ORPHAN_VISUAL_ELEMENT` and MUST block Basic Design Freeze. A required user-observable function without a visual/state binding is `MISSING_VISUAL_BINDING` and MUST block Basic Design Freeze unless Current Authority explicitly classifies it as `NON_VISUAL_SYSTEM_FUNCTION`.

Visual Design MUST preserve the approved Functional Workbench and Interaction Topology. Geometry and presentation MAY vary only within the Current Visual Authority / Design System and approved design change set; arbitrary visual regrouping, reordering, detaching, or separating operations from their required context is forbidden.'''),
'WEB-GOV-01-S078': ('78','強制完整視覺設計與多情境圖面 Gate / Mandatory Complete Visual Design and Multi-State Evidence', r'''Basic Design MUST include actual visual design, not information architecture, wireframes, moodboards, or text-only layout descriptions alone. Every required Visual Candidate MUST apply the Current project visual style or the newly approved `VISUAL_STYLE_DEFINITION` and must be detailed enough for human design review before Basic Design Freeze.

The applicability set MUST evaluate at least:

- `VISUAL_ARCHITECTURE_OVERVIEW`: information hierarchy, workbench boundaries, adjacency, navigation intent, feedback location, and semantic order.
- `CANONICAL_WORKSPACE_OVERVIEW`: complete primary page/workspace visual using the approved style, shell relationship, layout/grid, sections, controls, and primary next action.
- `VISUAL_STYLE_BOARD`: color/token roles, typography, density/spacing, shape/elevation, iconography, surfaces, control variants, and state semantics.
- `INTERACTION_TOPOLOGY_DIAGRAM`: REQUIRED for contiguous, multi-step, conditional, or cross-surface journeys.
- `INITIAL_OR_EMPTY_STATE`: REQUIRED when create/select/empty prerequisites exist.
- `ACTIVE_WORKING_STATE`: REQUIRED for every interactive workbench.
- `COMPLEX_OR_CONDITIONAL_STATE`: REQUIRED when compare, multi-agent, correction, layer, async/provider, branch, review, or equivalent behavior exists.
- `FINALIZATION_OR_CONFIRMATION_STATE`: REQUIRED when candidate, confirmation, approval, version, lock, publish, or equivalent finalization exists.
- `ERROR_BLOCKED_RECOVERY_STATE`: REQUIRED when user-visible error, disabled gate, retry, rollback, or recovery exists.
- `CROSS_PAGE_RELATION_DIAGRAM`: REQUIRED when another page/surface consumes or produces related design context.
- `RESPONSIVE_VARIANT`: REQUIRED when responsive behavior materially changes layout while semantic order must remain stable.

One overview image MUST_NOT substitute for the required scenario set. All visuals for one governed scope MUST use the same approved Layout, Visual Style, Design Tokens, Component State System, Visual Anchors, and Functional Topology unless an authorized Basic Design Change Set explicitly changes them.'''),
'WEB-GOV-01-S079': ('79','視覺參考註解合約 / Visual Reference Annotation Contract', r'''Every Visual Candidate MUST carry a machine- and human-readable annotation record containing at least:

- Visual UID, Page/Scope UID, Scenario UID, State UID, Workbench UID, Journey UID.
- Parent Visual UID, Design Version, Basic Design Change Set UID, Viewport, Language, Theme when applicable.
- Applicable Business Entity / Operation.
- Visible Sections and Conditional Sections.
- Locked Regions and Editable Regions.
- Visual Anchor UIDs.
- Primary Controls and Disabled/Blocked Controls with reason source.
- Current Next Action / Next Gate where the design exposes one.
- Source Authority references and Authority classification.
- Inherited Visual Authority / Design System references.
- A concise `verification_purpose` stating exactly what product behavior, relationship, or state the visual proves.

An image without the required annotation MUST_NOT satisfy Visual Preview, Visual Review, Basic Design Freeze, or a human-readable Basic Design deliverable.'''),
'WEB-GOV-01-S080': ('80','視覺規範繼承與風格定義 Gate / Visual Authority Inheritance and Style Definition', r'''Before creating page/surface visual design, Basic Design MUST independently resolve and read the Current applicable Visual Architecture, Design System, Layout/Shell, Component, Iconography, Brand, Asset, and visual-state authorities for the project/scope. The design MUST produce a `VISUAL_INHERITANCE_MATRIX` recording at least: Source Authority UID/Path/Version/Hash; inherited rule/token/component; lock/override status; allowed page-local variation; and required Change Set when deviation is permitted.

If an applicable Current visual authority exists, Basic Design MUST inherit it and MUST_NOT silently redefine global palette, typography, density, icon language, control geometry, component states, layout shell, spacing scale, or visual semantics.

If no applicable visual authority exists, Basic Design MUST create and approve a complete `VISUAL_STYLE_DEFINITION` before final Visual Candidates. The definition MUST cover at least:

- design intent / visual character / density level;
- color roles and token model, including primary/secondary/surface/text/border/status semantics;
- typography families/roles/scale/weight/line-height intent;
- spacing/density scale, grid, section gaps, padding, alignment, and content width behavior;
- geometry language: control heights, radius scale, borders, elevation/shadow, separators;
- iconography: icon family/style, stroke/fill policy, sizes, semantic usage, active/disabled/status rules;
- button, input, select, tab, card, table/list, badge/status, modal, drawer, tooltip/popover, conversation/message, and other applicable component variants;
- default/hover/focus/active/selected/loading/disabled/success/warning/error/processing state semantics;
- image/illustration/avatar/thumbnail/background treatment when applicable;
- motion/transition intent when applicable;
- responsive behavior and semantic reflow rules;
- accessibility: focus visibility, contrast, touch target, reading/focus order, non-color-only state communication;
- localization/i18n behavior and text expansion tolerance;
- theme/brand constraints and prohibited visual deviations.

The visual style MUST be coherent, reproducible, and reusable across the governed scope. Page-local design MAY specialize only what the Current Visual Authority explicitly leaves open. Any material style deviation from an existing Current Authority requires an authorized Basic Design Change Set and MUST update the inheritance matrix.'''),
'WEB-GOV-01-S081': ('81','情境對功能視覺覆蓋 Gate / Scenario-to-Function Visual Coverage', r'''Every critical Journey step, legal state transition, decision branch, permission-disabled state, asynchronous pending state, finalization state, and registered recovery branch MUST have explicit visual coverage when user-visible or user-observable.

Coverage MUST be computed from the approved Required Journey/State denominator, not from the number of images produced. Each required scenario MUST map to exact Workbench, Function/Operation, State, Controls, Visual Anchors, Visual Style/Inheritance references, and Design Review Items. Multiple scenarios MAY share one visual only when the annotation proves all required states are simultaneously and unambiguously represented.

A visual scenario that changes functional topology, semantic order, context identity, style authority, control ownership, or next-step placement without an approved Basic Design Change Set is `VISUAL_SCENARIO_DRIFT` and MUST block Basic Design Freeze.'''),
'WEB-GOV-01-S082': ('82','量化 Basic Design Freeze 完整度 Gate / Quantitative Basic Design Freeze Completeness', r'''`BASIC_DESIGN_FROZEN` MUST require machine-checkable design completeness for every applicable denominator. At minimum:

- Requirement / Architecture coverage = 100%.
- Required Business Entity Operation coverage = 100%.
- Required Journey / Workbench / Interaction Topology coverage = 100%.
- Required Functional Chain design coverage = 100%.
- Required Function -> Visual binding coverage = 100%.
- Visible Visual Element -> Function/Utility binding coverage = 100%.
- Visual Authority inheritance classification = 100%.
- Required Visual Style Definition category coverage = 100%.
- Required State/Scenario Visual coverage = 100%.
- Required Cross-page design relationship coverage = 100% when applicable.
- Required Design Review Item definition = 100%.
- Required embedded-figure coverage in the human-readable Basic Design deliverable = 100%.
- Orphan Visual Element count = 0.
- Unbound required Control count = 0.
- Unbound required Field count = 0.
- Undefined required Next Step count = 0.
- Missing required Recovery Path count = 0.
- Missing required Visual Candidate count = 0.
- Missing Visual Style category count = 0.
- Missing required figure annotation/caption count = 0.
- Unresolved Visual Authority conflict count = 0.

A percentage MUST_NOT hide an unresolved `AUTHORITY_GAP`, `AUTHORITY_CONFLICT`, missing Current visual owner, or intentionally fail-closed condition. One overview screenshot, wireframe, moodboard, or successful visual review item MUST_NOT substitute for the complete Basic Design denominator.'''),
'WEB-GOV-01-S083': ('83','設計文件圖面嵌入與自足性交付合約 / Design Document Embedded Visuals and Self-Contained Delivery Contract', r'''Every human-readable Basic Design deliverable — including DOCX, PDF, HTML, or equivalent review format — MUST embed the required design figures directly in the relevant document sections. External image files, links, registries, or machine-readable manifests MAY supplement the document but MUST_NOT be the only visual delivery.

Applicable embedded figures MUST include, at minimum:

- Architecture / Module / Dependency diagram near the Architecture section when structural relationships are non-trivial.
- Entity / Hierarchy / Relationship diagram when entity hierarchy or ownership relationships are material to use.
- User Journey / Functional Workbench / Interaction Topology diagram near the corresponding flow/design section.
- High-fidelity Page/Workspace visual near each Page/Surface Design section.
- Visual Style Board / Design System reference near the Visual Style section.
- Required multi-state visuals adjacent to their State / Interaction / Recovery sections.
- Cross-page relationship diagram where cross-page design relationships are applicable.
- Responsive variant figures where responsive behavior materially changes geometry or arrangement.

Every embedded figure MUST have a readable resolution and an adjacent caption/annotation summary containing: Figure/Visual UID; title; design purpose; Page/Scope; Scenario/State; source/inherited Visual Authority references; Design Version/Change Set; and key review notes. The document MUST explain what each figure validates and which design relationships are intentionally locked.

The human-readable design deliverable MUST be self-contained enough for a reviewer to understand the approved architecture, functional relationships, visual style, page composition, major states, and design constraints without opening separate image files merely to discover what the design looks like.

This contract governs Basic Design documentation only. It does not require or define source code, construction delta, implementation manifest, runtime verification, deployment, or production evidence.'''),
}

OLD_IMPL_PARAGRAPH = '''### Blueprint package / construction delta consumption hardening\n\nImplementation MUST consume the frozen `CONSTRUCTION_BLUEPRINT_PACKAGE`, `CONSTRUCTION_DELTA_MATRIX`, required annotated Visual Candidates, and `BLUEPRINT_IMPLEMENTATION_HANDOFF` produced by the design/freeze owners. A visible element, code artifact, handler, runtime path, or state projection without bidirectional Requirement/Operation/Visual/Acceptance traceability is an implementation defect. Existing code marked `PARTIAL`, `WRONG_BINDING`, `OBSOLETE`, or `DUPLICATE` MUST follow the exact frozen disposition; implementation MUST_NOT preserve it merely because it already exists.\n\nImplementation MUST_NOT substitute an arbitrary UI layout for the approved Workbench/Interaction Topology. If code reality exposes a new required delta outside the frozen handoff, execution MUST re-enter the owning design capability rather than silently expanding implementation.\n\n'''
OLD_AUDIT_PARAGRAPH = '''### Blueprint construction traceability / visual evidence audit hardening\n\nAudit MUST verify the applicable `CONSTRUCTION_BLUEPRINT_PACKAGE` is complete and non-owning, preserves separate Page/Visual Authorities, and binds every REQUIRED function bidirectionally through Entity/Operation/Journey/Workbench/Section/Component/Control-or-Trigger/Field-or-Input/State/Visual Anchor/Visual Candidate/Implementation Target/Acceptance Item.\n\nAudit MUST verify required multi-state visual scenarios and annotations, zero orphan visual elements, zero unbound required controls/fields, complete required state/recovery/cross-page visual coverage, complete `CONSTRUCTION_DELTA_MATRIX` classification when prior implementation exists, quantitative Design Freeze denominators, and an exact Blueprint-to-Implementation Handoff. A visually attractive overview without these bindings MUST_NOT PASS.\n\n'''

def run(*args, check=True, env=None):
    cp = subprocess.run(args, cwd=ROOT, text=True, capture_output=True, env=env)
    if check and cp.returncode:
        print(cp.stdout)
        print(cp.stderr, file=sys.stderr)
        raise SystemExit(cp.returncode)
    return cp

def load(path):
    return yaml.safe_load(Path(path).read_text(encoding='utf-8')) or {}

def dump(path, obj):
    Path(path).write_text(yaml.safe_dump(obj, allow_unicode=True, sort_keys=False, width=180), encoding='utf-8')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def hobj(d):
    x = copy.deepcopy(d); x.pop('content_hash', None)
    return hashlib.sha256(yaml.safe_dump(x, allow_unicode=True, sort_keys=True, width=180).encode()).hexdigest()

def replace_exact_once(text, old, new):
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'BOUNDED_REPLACE_TARGET_COUNT expected=1 actual={n}')
    i = text.index(old)
    return text[:i] + new + text[i+len(old):]

def replace_section(path: Path, uid: str, number: str, title: str, body: str):
    text = path.read_text(encoding='utf-8')
    marker = f'<!-- SECTION_UID: {uid} -->'
    start = text.find(marker)
    if start < 0:
        raise RuntimeError(f'SECTION_MARKER_MISSING:{uid}')
    nxt = text.find('<!-- SECTION_UID:', start + len(marker))
    end = len(text) if nxt < 0 else nxt
    replacement = f'{marker}\n## {number}. {title}\n\n{body.strip()}\n\n'
    path.write_text(text[:start] + replacement + text[end:], encoding='utf-8')

def section_binding(uid, doc_id, path, heading):
    return hashlib.sha256(f'{uid}\n{doc_id}\n{path}\n{heading}\n'.encode()).hexdigest()

def unique_extend(lst, items):
    for item in items:
        if item not in lst:
            lst.append(item)

def remove_items(lst, items):
    ban = set(items)
    return [x for x in lst if x not in ban]

def mutate_mother():
    p = SOURCE/'12_DOCS/mother-spec/01_BLUEPRINT_DESIGN_GOVERNANCE.md'
    for uid,(num,title,body) in SECTIONS.items():
        replace_section(p, uid, num, title, body)

    p2 = SOURCE/'12_DOCS/mother-spec/02_IMPLEMENTATION_DELIVERY_STANDARD.md'
    t = p2.read_text(encoding='utf-8')
    if OLD_IMPL_PARAGRAPH not in t:
        raise RuntimeError('OLD_IMPLEMENTATION_COUPLING_PARAGRAPH_MISSING')
    p2.write_text(replace_exact_once(t, OLD_IMPL_PARAGRAPH, ''), encoding='utf-8')

    p4 = SOURCE/'12_DOCS/mother-spec/04_AUDIT_PROGRESS_STANDARD.md'
    t = p4.read_text(encoding='utf-8')
    if OLD_AUDIT_PARAGRAPH not in t:
        raise RuntimeError('OLD_AUDIT_COUPLING_PARAGRAPH_MISSING')
    p4.write_text(replace_exact_once(t, OLD_AUDIT_PARAGRAPH, ''), encoding='utf-8')

def mutate_section_registry():
    p = SOURCE/'10_REGISTRY/SECTION_NUMBER_REGISTRY.yaml'; d = load(p)
    doc = next(x for x in d['documents'] if x.get('document_id') == 'WEB-GOV-01')
    rel = '12_DOCS/mother-spec/01_BLUEPRINT_DESIGN_GOVERNANCE.md'
    by = {x.get('section_uid'):x for x in doc.get('sections',[])}
    for uid,(num,title,_) in SECTIONS.items():
        sec = by.get(uid)
        if not sec: raise RuntimeError('SECTION_REGISTRY_UID_MISSING:'+uid)
        heading=f'## {num}. {title}'
        sec['canonical_number']=num; sec['title']=title; sec['heading']=heading; sec['path']=rel
        sec['binding_sha256']=section_binding(uid,'WEB-GOV-01',rel,heading)
    d['governance_revision']=NEW_SOURCE_REV
    dump(p,d)

def mutate_lifecycle_and_refs():
    uids=list(SECTIONS)
    lp=SOURCE/'10_REGISTRY/GOVERNANCE_LIFECYCLE_STAGE_REGISTRY.yaml'; d=load(lp)
    stage={x.get('stage_uid'):x for x in d.get('stages',[])}
    s4=stage['STAGE-04']; unique_extend(s4.setdefault('required_normative_section_uids',[]),uids)
    s4.setdefault('operations',[])
    if 'BASIC_DESIGN_PACKAGE_COMPILE' not in s4['operations']:
        s4['operations'].insert(0,'BASIC_DESIGN_PACKAGE_COMPILE')
    s4.setdefault('outputs',[])
    if 'BASIC_DESIGN_PACKAGE' not in s4['outputs']:
        s4['outputs'].insert(0,'BASIC_DESIGN_PACKAGE')
    s4.setdefault('output_producers',{})['BASIC_DESIGN_PACKAGE']='BASIC_DESIGN_PACKAGE_COMPILE'
    s5=stage['STAGE-05']; s5['required_normative_section_uids']=remove_items(s5.get('required_normative_section_uids',[]),uids)
    cs=d.setdefault('cross_stage_invariants',{}).setdefault('stage_execution_invariant_hardening',{})
    for old in ['construction_blueprint_package_required_before_freeze_and_implementation','construction_delta_matrix_required_when_prior_implementation_exists','quantitative_design_freeze_completeness_required','blueprint_to_implementation_handoff_required']:
        cs.pop(old,None)
    cs.update({
      'basic_design_package_required_before_basic_design_freeze':True,
      'function_visual_bidirectional_traceability_required':True,
      'mandatory_complete_visual_design_required_when_applicable':True,
      'visual_reference_annotation_required':True,
      'visual_inheritance_matrix_and_style_definition_required':True,
      'scenario_to_function_visual_coverage_required':True,
      'quantitative_basic_design_freeze_completeness_required':True,
      'human_readable_design_document_embedded_visuals_required':True,
      'basic_design_independent_of_implementation_execution_and_deployment':True,
    })
    d['governance_revision']=NEW_SOURCE_REV; dump(lp,d)

    rp=SOURCE/'10_REGISTRY/REFERENCE_RULE_REGISTRY.yaml'; r=load(rp)
    rules=r.get('stage_reference_rules') or {}
    unique_extend(rules['STAGE-04']['exact_required_normative_section_uids'],uids)
    rules['STAGE-05']['exact_required_normative_section_uids']=remove_items(rules['STAGE-05'].get('exact_required_normative_section_uids',[]),uids)
    for x in r.setdefault('blueprint_type_identities',[]):
        if x.get('blueprint_type_uid')=='BPTYPE-GOV-007':
            x.update({'canonical_name':'BASIC_DESIGN_PACKAGE','planning_domain':'BASIC_DESIGN','created_stage_uid':'STAGE-04'})
    r['governance_revision']=NEW_SOURCE_REV; dump(rp,r)

    sp=SOURCE/'10_REGISTRY/SEMANTIC_AUTHORITY_BASELINE.yaml'; s=load(sp)
    srules=s['semantic_snapshot']['stage_reference_rules']
    unique_extend(srules['STAGE-04']['exact_required_normative_section_uids'],uids)
    srules['STAGE-05']['exact_required_normative_section_uids']=remove_items(srules['STAGE-05'].get('exact_required_normative_section_uids',[]),uids)
    for x in s['semantic_snapshot'].setdefault('blueprint_type_identities',[]):
        if x.get('blueprint_type_uid')=='BPTYPE-GOV-007':
            x.update({'canonical_name':'BASIC_DESIGN_PACKAGE','planning_domain':'BASIC_DESIGN','created_stage_uid':'STAGE-04'})
    s['governance_revision']=NEW_SOURCE_REV; s['content_hash']=hobj(s); dump(sp,s)
    return s['content_hash']

def mutate_invariants():
    p=SOURCE/'10_REGISTRY/STAGE_EXECUTION_INVARIANT_REGISTRY.yaml'; d=load(p); inv=d.setdefault('invariants',{})
    for old in ['CONSTRUCTION_BLUEPRINT_PACKAGE_COMPLETENESS','CONSTRUCTION_DELTA_EXISTING_IMPLEMENTATION','DESIGN_FREEZE_QUANTITATIVE_COMPLETENESS','BLUEPRINT_TO_IMPLEMENTATION_HANDOFF']:
        inv.pop(old,None)
    inv['BASIC_DESIGN_PACKAGE_COMPLETENESS']={
      'required_artifact':'BASIC_DESIGN_PACKAGE','design_domain_only':True,'independent_of_implementation_runtime_deployment':True,
      'required_domains':['REQUIREMENTS','ARCHITECTURE','BUSINESS_ENTITY_AND_OPERATION','JOURNEY_WORKBENCH_TOPOLOGY','PAGE_SURFACE_DESIGN','VISUAL_ARCHITECTURE','VISUAL_INHERITANCE_MATRIX','VISUAL_STYLE_DEFINITION','FUNCTION_VISUAL_TRACEABILITY','VISUAL_SCENARIO_EVIDENCE_SET','VISUAL_REFERENCE_ANNOTATION','HUMAN_READABLE_DESIGN_DOCUMENT','DESIGN_REVIEW_AND_FREEZE_STATE'],
      'missing_applicable_package_item':'BASIC_DESIGN_PACKAGE_INCOMPLETE','basic_design_freeze_before_complete_package':'BLOCK'}
    inv['FUNCTION_VISUAL_BIDIRECTIONAL_TRACEABILITY']={
      'required_forward_trace':['BUSINESS_ENTITY','OPERATION','JOURNEY','FUNCTIONAL_WORKBENCH','SECTION','COMPONENT','CONTROL_OR_SYSTEM_TRIGGER','FIELD_OR_INPUT','STATE','VISUAL_ANCHOR','VISUAL_CANDIDATE','DESIGN_REVIEW_ITEM'],
      'reverse_trace_required_for_visible_interactive_or_state_bearing_elements':True,
      'orphan_visual_element':'BLOCK','required_user_observable_function_without_visual_binding':'BLOCK','non_visual_system_function_requires_authority':True,'arbitrary_visual_topology_change':'BLOCK'}
    inv['MANDATORY_MULTI_STATE_VISUAL_EVIDENCE']={
      'required_artifact':'VISUAL_SCENARIO_EVIDENCE_SET','actual_visual_design_required':True,'wireframe_only_is_complete_visual_design':False,'style_application_required':True,
      'scenario_universe':['VISUAL_ARCHITECTURE_OVERVIEW','CANONICAL_WORKSPACE_OVERVIEW','VISUAL_STYLE_BOARD','INTERACTION_TOPOLOGY_DIAGRAM','INITIAL_OR_EMPTY_STATE','ACTIVE_WORKING_STATE','COMPLEX_OR_CONDITIONAL_STATE','FINALIZATION_OR_CONFIRMATION_STATE','ERROR_BLOCKED_RECOVERY_STATE','CROSS_PAGE_RELATION_DIAGRAM','RESPONSIVE_VARIANT'],
      'applicability_required':True,'missing_required_scenario':'BLOCK','same_style_layout_tokens_anchors_topology_required_unless_design_change_set':True}
    inv['VISUAL_REFERENCE_ANNOTATION']={
      'required_artifact':'VISUAL_REFERENCE_ANNOTATION','required_fields':['visual_uid','page_or_scope_uid','scenario_uid','state_uid','workbench_uid','journey_uid','parent_visual_uid','design_version','basic_design_change_set_uid','viewport','language','theme','applicable_entity_operation','visible_sections','conditional_sections','locked_regions','editable_regions','visual_anchor_uids','primary_controls','disabled_or_blocked_controls','next_action_or_gate','source_authority_refs','inherited_visual_authority_refs','authority_classification','verification_purpose'],
      'unannotated_visual_may_pass_visual_review':False}
    inv['VISUAL_INHERITANCE_AND_STYLE_DEFINITION']={
      'required_artifacts':['VISUAL_INHERITANCE_MATRIX','VISUAL_STYLE_DEFINITION'],
      'read_current_visual_authorities_before_design':True,'inherit_existing_current_visual_authority_when_present':True,'silent_global_style_redefinition':'BLOCK',
      'missing_current_visual_authority_requires_new_style_definition_before_final_visuals':True,
      'style_category_universe':['DESIGN_INTENT','COLOR_ROLE_TOKEN_MODEL','TYPOGRAPHY','SPACING_DENSITY_GRID','GEOMETRY_RADIUS_BORDER_ELEVATION','ICONOGRAPHY','CONTROL_AND_COMPONENT_VARIANTS','STATE_SEMANTICS','MEDIA_ASSET_TREATMENT','MOTION','RESPONSIVE','ACCESSIBILITY','LOCALIZATION','THEME_BRAND_CONSTRAINTS'],
      'page_local_specialization_requires_authority_open_slot':True,'material_style_deviation_requires_basic_design_change_set':True}
    inv['SCENARIO_TO_FUNCTION_VISUAL_COVERAGE']={
      'denominator':'APPROVED_REQUIRED_JOURNEY_STATE_BRANCH_SET','required_mapping':['WORKBENCH','FUNCTION_OR_OPERATION','STATE','CONTROLS','VISUAL_ANCHORS','VISUAL_STYLE_OR_INHERITANCE_REFS','DESIGN_REVIEW_ITEMS'],'required_coverage_percent':100,'visual_scenario_drift':'BLOCK'}
    inv['BASIC_DESIGN_FREEZE_QUANTITATIVE_COMPLETENESS']={
      'required_percent_fields':{'requirement_architecture_coverage':100,'business_entity_operation_coverage':100,'journey_workbench_topology_coverage':100,'functional_chain_design_coverage':100,'function_to_visual_binding_coverage':100,'visible_visual_to_function_binding_coverage':100,'visual_authority_inheritance_classification':100,'visual_style_definition_category_coverage':100,'required_state_scenario_visual_coverage':100,'cross_page_design_relation_coverage_when_applicable':100,'required_design_review_item_definition':100,'human_readable_embedded_figure_coverage':100},
      'required_zero_fields':['orphan_visual_element_count','unbound_required_control_count','unbound_required_field_count','undefined_required_next_step_count','missing_required_recovery_path_count','missing_required_visual_candidate_count','missing_visual_style_category_count','missing_required_figure_annotation_count','unresolved_visual_authority_conflict_count'],
      'authority_gap_may_be_hidden_by_percentage':False,'single_overview_or_wireframe_may_substitute_denominator':False}
    inv['DESIGN_DOCUMENT_VISUAL_EMBEDDING']={
      'applies_to_human_readable_design_deliverables':['DOCX','PDF','HTML','EQUIVALENT_REVIEW_FORMAT'],
      'external_image_only_delivery':'BLOCK','required_figures_embedded_adjacent_to_relevant_section':True,
      'figure_categories':['ARCHITECTURE_OR_MODULE_RELATION','ENTITY_OR_HIERARCHY_WHEN_MATERIAL','JOURNEY_WORKBENCH_INTERACTION_TOPOLOGY','HIGH_FIDELITY_PAGE_OR_WORKSPACE','VISUAL_STYLE_BOARD_OR_DESIGN_SYSTEM_REFERENCE','MULTI_STATE_VISUALS','CROSS_PAGE_RELATION_WHEN_APPLICABLE','RESPONSIVE_VARIANT_WHEN_APPLICABLE'],
      'required_caption_fields':['figure_or_visual_uid','title','design_purpose','page_or_scope','scenario_or_state','source_or_inherited_visual_authority_refs','design_version_or_change_set','key_review_notes'],
      'self_contained_human_review_required':True,'implementation_artifacts_required':False}
    d['governance_revision']=NEW_SOURCE_REV; dump(p,d)

def mutate_blueprint_acceptance_index():
    bp=SOURCE/'10_REGISTRY/BLUEPRINT_REGISTRY.yaml'; d=load(bp)
    for x in d.get('blueprint_types',[]):
        if x.get('blueprint_type_uid')=='BPTYPE-GOV-007':
            x.update({'blueprint_type':'BASIC_DESIGN_PACKAGE','planning_domain':'BASIC_DESIGN','created_stage_uid':'STAGE-04','owner_mode':'BINDING_ONLY'})
    d['governance_revision']=NEW_SOURCE_REV; dump(bp,d)

    ap=SOURCE/'10_REGISTRY/GOVERNANCE_ACCEPTANCE_AUDIT_BLUEPRINT.yaml'; a=load(ap); c=a.setdefault('product_neutral_entity_lifecycle_contract',{})
    for old in ['construction_blueprint_package_required','construction_delta_matrix_required_when_prior_implementation_exists','quantitative_design_freeze_completeness_required','blueprint_to_implementation_handoff_required']:
        c.pop(old,None)
    c.update({
      'basic_design_package_required':True,'basic_design_independent_of_implementation_runtime_deployment':True,
      'function_visual_bidirectional_traceability_required':True,'mandatory_complete_visual_design_required':True,'visual_reference_annotation_required':True,
      'visual_inheritance_matrix_required':True,'visual_style_definition_required':True,'scenario_to_function_visual_coverage_required':True,
      'quantitative_basic_design_freeze_completeness_required':True,'human_readable_design_document_embedded_visuals_required':True,
      'visual_style_category_coverage_required':True,'orphan_visual_element_zero_required':True,'unbound_control_zero_required':True,'unbound_field_zero_required':True,
      'undefined_next_step_zero_required':True,'missing_recovery_path_zero_required':True,'required_visual_candidate_missing_zero_required':True,
      'missing_visual_style_category_zero_required':True,'missing_required_figure_annotation_zero_required':True,'unresolved_visual_authority_conflict_zero_required':True,
      'arbitrary_visual_layout_without_topology_binding':'BLOCK','silent_global_style_redefinition':'BLOCK','external_image_only_basic_design_delivery':'BLOCK'})
    a['governance_revision']=NEW_SOURCE_REV; dump(ap,a)

    idx=SOURCE/'10_REGISTRY/CONSTRUCTION_ARTIFACT_INDEX.yaml'; x=load(idx); ur=x.setdefault('universal_rules',{})
    for old in ['construction_blueprint_package_incomplete','function_visual_traceability_missing','orphan_visual_element','required_visual_scenario_missing','unannotated_visual_candidate','construction_delta_unclassified','design_freeze_quantitative_coverage_incomplete','blueprint_handoff_unbound','arbitrary_visual_layout_without_functional_topology_binding']:
        ur.pop(old,None)
    x['governance_revision']=NEW_SOURCE_REV; dump(idx,x)

    for rel in ['10_REGISTRY/AUDIT_CATALOG.yaml']:
        p=SOURCE/rel; y=load(p); y['governance_revision']=NEW_SOURCE_REV; dump(p,y)

def mutate_validator():
    p=SOURCE/'09_TESTS/governance/validate_product_neutral_entity_lifecycle.py'; s=p.read_text(encoding='utf-8')
    start=s.find("    cb=inv.get('CONSTRUCTION_BLUEPRINT_PACKAGE_COMPLETENESS')")
    end=s.find("    return {'status':'PASS' if not failures else 'FAIL'", start)
    if start<0 or end<0: raise RuntimeError('V2210_VALIDATOR_BLOCK_NOT_FOUND')
    block=r'''    bd=inv.get('BASIC_DESIGN_PACKAGE_COMPLETENESS') or {}
    if bd.get('required_artifact')!='BASIC_DESIGN_PACKAGE' or bd.get('design_domain_only') is not True or bd.get('independent_of_implementation_runtime_deployment') is not True: failures.append('basic_design_package_contract_missing')
    if bd.get('missing_applicable_package_item')!='BASIC_DESIGN_PACKAGE_INCOMPLETE' or bd.get('basic_design_freeze_before_complete_package')!='BLOCK': failures.append('basic_design_package_fail_closed_invalid')
    fv=inv.get('FUNCTION_VISUAL_BIDIRECTIONAL_TRACEABILITY') or {}
    if fv.get('reverse_trace_required_for_visible_interactive_or_state_bearing_elements') is not True or fv.get('orphan_visual_element')!='BLOCK' or fv.get('required_user_observable_function_without_visual_binding')!='BLOCK' or fv.get('arbitrary_visual_topology_change')!='BLOCK': failures.append('function_visual_bidirectional_traceability_invalid')
    mv=inv.get('MANDATORY_MULTI_STATE_VISUAL_EVIDENCE') or {}
    required_scenarios={'VISUAL_ARCHITECTURE_OVERVIEW','CANONICAL_WORKSPACE_OVERVIEW','VISUAL_STYLE_BOARD','INTERACTION_TOPOLOGY_DIAGRAM','INITIAL_OR_EMPTY_STATE','ACTIVE_WORKING_STATE','COMPLEX_OR_CONDITIONAL_STATE','FINALIZATION_OR_CONFIRMATION_STATE','ERROR_BLOCKED_RECOVERY_STATE','CROSS_PAGE_RELATION_DIAGRAM','RESPONSIVE_VARIANT'}
    if mv.get('required_artifact')!='VISUAL_SCENARIO_EVIDENCE_SET' or set(mv.get('scenario_universe') or [])!=required_scenarios or mv.get('actual_visual_design_required') is not True or mv.get('wireframe_only_is_complete_visual_design') is not False or mv.get('style_application_required') is not True or mv.get('missing_required_scenario')!='BLOCK': failures.append('complete_visual_design_evidence_contract_invalid')
    va=inv.get('VISUAL_REFERENCE_ANNOTATION') or {}
    if va.get('required_artifact')!='VISUAL_REFERENCE_ANNOTATION' or va.get('unannotated_visual_may_pass_visual_review') is not False or 'verification_purpose' not in (va.get('required_fields') or []) or 'inherited_visual_authority_refs' not in (va.get('required_fields') or []): failures.append('visual_reference_annotation_contract_invalid')
    vi=inv.get('VISUAL_INHERITANCE_AND_STYLE_DEFINITION') or {}
    required_style={'DESIGN_INTENT','COLOR_ROLE_TOKEN_MODEL','TYPOGRAPHY','SPACING_DENSITY_GRID','GEOMETRY_RADIUS_BORDER_ELEVATION','ICONOGRAPHY','CONTROL_AND_COMPONENT_VARIANTS','STATE_SEMANTICS','MEDIA_ASSET_TREATMENT','MOTION','RESPONSIVE','ACCESSIBILITY','LOCALIZATION','THEME_BRAND_CONSTRAINTS'}
    if set(vi.get('required_artifacts') or [])!={'VISUAL_INHERITANCE_MATRIX','VISUAL_STYLE_DEFINITION'} or vi.get('read_current_visual_authorities_before_design') is not True or vi.get('inherit_existing_current_visual_authority_when_present') is not True or vi.get('silent_global_style_redefinition')!='BLOCK' or set(vi.get('style_category_universe') or [])!=required_style: failures.append('visual_inheritance_or_style_definition_invalid')
    sv=inv.get('SCENARIO_TO_FUNCTION_VISUAL_COVERAGE') or {}
    if sv.get('denominator')!='APPROVED_REQUIRED_JOURNEY_STATE_BRANCH_SET' or int(sv.get('required_coverage_percent',0))!=100 or sv.get('visual_scenario_drift')!='BLOCK': failures.append('scenario_visual_coverage_contract_invalid')
    df=inv.get('BASIC_DESIGN_FREEZE_QUANTITATIVE_COMPLETENESS') or {}
    if any(int(v)!=100 for v in (df.get('required_percent_fields') or {}).values()) or len(df.get('required_zero_fields') or [])<9 or df.get('authority_gap_may_be_hidden_by_percentage') is not False or df.get('single_overview_or_wireframe_may_substitute_denominator') is not False: failures.append('quantitative_basic_design_freeze_contract_invalid')
    de=inv.get('DESIGN_DOCUMENT_VISUAL_EMBEDDING') or {}
    if de.get('external_image_only_delivery')!='BLOCK' or de.get('required_figures_embedded_adjacent_to_relevant_section') is not True or de.get('self_contained_human_review_required') is not True or de.get('implementation_artifacts_required') is not False: failures.append('design_document_visual_embedding_contract_invalid')
    for k in ['basic_design_package_required','basic_design_independent_of_implementation_runtime_deployment','function_visual_bidirectional_traceability_required','mandatory_complete_visual_design_required','visual_reference_annotation_required','visual_inheritance_matrix_required','visual_style_definition_required','scenario_to_function_visual_coverage_required','quantitative_basic_design_freeze_completeness_required','human_readable_design_document_embedded_visuals_required','visual_style_category_coverage_required','orphan_visual_element_zero_required','unbound_control_zero_required','unbound_field_zero_required','undefined_next_step_zero_required','missing_recovery_path_zero_required','required_visual_candidate_missing_zero_required','missing_visual_style_category_zero_required','missing_required_figure_annotation_zero_required','unresolved_visual_authority_conflict_zero_required']:
        if c.get(k) is not True: failures.append('acceptance_basic_design_rule_missing:'+k)
    if c.get('arbitrary_visual_layout_without_topology_binding')!='BLOCK' or c.get('silent_global_style_redefinition')!='BLOCK' or c.get('external_image_only_basic_design_delivery')!='BLOCK': failures.append('acceptance_basic_design_fail_closed_invalid')
    for uid in ['WEB-GOV-01-S076','WEB-GOV-01-S077','WEB-GOV-01-S078','WEB-GOV-01-S079','WEB-GOV-01-S080','WEB-GOV-01-S081','WEB-GOV-01-S082','WEB-GOV-01-S083']:
        if uid not in (root/'12_DOCS/mother-spec/01_BLUEPRINT_DESIGN_GOVERNANCE.md').read_text(encoding='utf-8'): failures.append('mother_basic_design_section_missing:'+uid)
'''
    p.write_text(s[:start]+block+'\n'+s[end:],encoding='utf-8')

def mutate_current_components():
    p=ROOT/'governance/specifications/current/BOUNDED_FUNCTIONAL_COMPLETION.yaml'; d=load(p); rules=d.setdefault('rules',{})
    for old in ['CONSTRUCTION_BLUEPRINT_PACKAGE_COMPLETENESS','CONSTRUCTION_DELTA_EXISTING_IMPLEMENTATION','QUANTITATIVE_DESIGN_FREEZE_COMPLETENESS','BLUEPRINT_TO_IMPLEMENTATION_HANDOFF']:
        rules.pop(old,None)
    rules['BASIC_DESIGN_PACKAGE_COMPLETENESS']={'required_artifact':'BASIC_DESIGN_PACKAGE','design_domain_only':True,'independent_of_implementation_runtime_deployment':True,'missing_applicable_item':'BASIC_DESIGN_PACKAGE_INCOMPLETE','basic_design_freeze_before_complete_package':'BLOCK'}
    rules['QUANTITATIVE_BASIC_DESIGN_FREEZE_COMPLETENESS']={'required_percent':100,'visual_inheritance_complete':True,'visual_style_complete':True,'required_embedded_visuals_complete':True,'orphan_visual_zero':True,'unbound_control_zero':True,'unbound_field_zero':True,'undefined_next_step_zero':True,'missing_recovery_zero':True,'missing_required_visual_zero':True,'authority_gap_hidden_by_percentage':'BLOCK'}
    d['schema_version']=5; dump(p,d)

    p=ROOT/'governance/specifications/current/INTERACTION_TOPOLOGY_AI_CONTINUITY.yaml'; d=load(p); ci=d.setdefault('common_invariants',{})
    fv=ci.setdefault('FUNCTION_VISUAL_BIDIRECTIONAL_TRACEABILITY',{})
    fv['forward_trace_required']=['BUSINESS_ENTITY','OPERATION','JOURNEY','FUNCTIONAL_WORKBENCH','SECTION','COMPONENT','CONTROL_OR_SYSTEM_TRIGGER','FIELD_OR_INPUT','STATE','VISUAL_ANCHOR','VISUAL_CANDIDATE','DESIGN_REVIEW_ITEM']
    mv=ci.setdefault('MANDATORY_MULTI_STATE_VISUAL_EVIDENCE',{})
    mv.update({'actual_visual_design_required':True,'wireframe_only_is_complete_visual_design':False,'style_application_required':True})
    ci['VISUAL_INHERITANCE_AND_STYLE_DEFINITION']={'required_contracts':['VISUAL_INHERITANCE_MATRIX','VISUAL_STYLE_DEFINITION'],'read_current_visual_authorities_before_design':True,'inherit_existing_current_visual_authority_when_present':True,'silent_global_style_redefinition':'BLOCK','complete_style_definition_required_when_authority_absent':True}
    ci['DESIGN_DOCUMENT_VISUAL_EMBEDDING']={'human_readable_design_document_required':True,'embedded_required_figures':True,'external_image_only_delivery':'BLOCK','self_contained_human_review_required':True,'implementation_artifacts_required':False}
    d['schema_version']=4; dump(p,d)

def append_version_docs():
    readme=SOURCE/'README.md'; t=readme.read_text(encoding='utf-8')
    marker='## v2.2.11 basic design visual integration hardening'
    if marker not in t:
        t=t.rstrip()+f'''\n\n{marker}\nThis successor corrects the Basic Design boundary: Basic Design is complete independently of implementation/execution and includes full visual design, inherited/current visual-authority resolution, complete visual-style definition, high-fidelity multi-state visuals, and embedded figures inside human-readable design documents. Product-specific colors, shell geometry, brand values, and component numbers remain outside common Mother policy and are inherited through project/product Visual Authority.\n'''
        readme.write_text(t,encoding='utf-8')
    vr=SOURCE/'VERSIONING_RULE.md'; t=vr.read_text(encoding='utf-8')
    marker='## v2.2.11 basic design visual integration rule'
    if marker not in t:
        t=t.rstrip()+f'''\n\n{marker}\n- Basic Design and downstream implementation/execution are separate lifecycle concerns.\n- Basic Design MUST finish requirements, architecture, functional relationships, visual architecture, complete visual style, high-fidelity scenario visuals, document-embedded figures, design review, and freeze without requiring code/runtime/deployment evidence.\n- Existing project Visual Authority MUST be read and inherited first; if absent, Basic Design MUST define and approve a complete reusable visual style before final visual candidates.\n- Common Mother policy remains product-neutral and MUST NOT embed a product-specific palette, brand, shell geometry, page name, route, provider, or fixed implementation technology.\n'''
        vr.write_text(t,encoding='utf-8')

def update_candidate_and_review():
    p=SOURCE/'11_EVIDENCE/audit/GOVERNANCE_CANDIDATE_STATE.yaml'; d=load(p)
    d['candidate']='v2.2.11_BASIC_DESIGN_VISUAL_INTEGRATION_CANDIDATE'; d['status']='CANDIDATE_UNDER_FRESH_SUCCESSOR_REVALIDATION'
    fr=d.setdefault('fresh_revalidation',{}); fr.update({'required':True,'current_source_revision':NEW_SOURCE_REV,'current_closure_credit':False,'predecessor_evidence_current_closure_credit':False,'embedded_preformal_execution_role':'HISTORICAL_PREDECESSOR_EVIDENCE_ONLY','predecessor_wrapper_result_role':'HISTORICAL_PREDECESSOR_EVIDENCE_ONLY','persisted_head_full_line_required':True,'historical_evidence_may_close_successor':False})
    dump(p,d)
    p=SOURCE/'10_REGISTRY/REVIEW_PROGRESS_LEDGER.yaml'; d=load(p); d['governance_revision']=NEW_SOURCE_REV; dump(p,d)

def replace_const(path, name, value):
    p=Path(path); s=p.read_text(encoding='utf-8')
    pat=re.compile(rf"(?m)^{re.escape(name)}\s*=\s*'[^']*'$|^{re.escape(name)}\s*=\s*\"[^\"]*\"$",re.M)
    m=list(pat.finditer(s))
    if len(m)!=1: raise RuntimeError(f'CONST_MATCH:{name}:{len(m)}')
    q="'"+value+"'"
    p.write_text(s[:m[0].start()]+f'{name} = {q}'+s[m[0].end():],encoding='utf-8')

def refresh_source_identity(semantic_hash):
    # Normalize current registries touched by this successor.
    for rel in ['10_REGISTRY/SECTION_NUMBER_REGISTRY.yaml','10_REGISTRY/REFERENCE_RULE_REGISTRY.yaml','10_REGISTRY/CONSTRUCTION_ARTIFACT_INDEX.yaml','10_REGISTRY/BLUEPRINT_REGISTRY.yaml','10_REGISTRY/GOVERNANCE_ACCEPTANCE_AUDIT_BLUEPRINT.yaml','10_REGISTRY/GOVERNANCE_LIFECYCLE_STAGE_REGISTRY.yaml','10_REGISTRY/STAGE_EXECUTION_INVARIANT_REGISTRY.yaml','10_REGISTRY/AUDIT_CATALOG.yaml']:
        p=SOURCE/rel; d=load(p); d['governance_revision']=NEW_SOURCE_REV; dump(p,d)
    rootp=SOURCE/'10_REGISTRY/GOVERNANCE_ROOT_MANIFEST.yaml'; rd=load(rootp); rd['governance_revision']=NEW_SOURCE_REV; dump(rootp,rd)
    replace_const(SOURCE/'09_TESTS/governance/validate_reference_semantics.py','SEMANTIC_BASELINE_CONTENT_HASH',semantic_hash)
    run(sys.executable,str(SOURCE/'09_TESTS/governance/compile_governance_baseline.py'))
    run(sys.executable,str(SOURCE/'09_TESTS/governance/refresh_governance_root_manifest.py'))
    run(sys.executable,str(SOURCE/'09_TESTS/governance/refresh_governance_root_manifest.py'))
    checks=SOURCE/'CHECKSUMS.sha256'
    files=sorted([p for p in SOURCE.rglob('*') if p.is_file() and p!=checks],key=lambda p:p.relative_to(SOURCE).as_posix())
    checks.write_text(''.join(f"{sha(p)}  {p.relative_to(SOURCE).as_posix()}\n" for p in files),encoding='utf-8')
    allfiles=sorted([p for p in SOURCE.rglob('*') if p.is_file()],key=lambda p:p.relative_to(SOURCE).as_posix())
    if len(allfiles)!=75: raise RuntimeError(f'SOURCE_FILE_COUNT_CHANGED:{len(allfiles)}')
    tar_buf=io.BytesIO()
    with tarfile.open(fileobj=tar_buf,mode='w',format=tarfile.PAX_FORMAT) as tf:
        for p in allfiles:
            rel=p.relative_to(SOURCE).as_posix(); info=tf.gettarinfo(str(p),arcname=rel); info.uid=0; info.gid=0; info.uname=''; info.gname=''; info.mtime=0
            with p.open('rb') as fh: tf.addfile(info,fh)
    bundle=lzma.compress(tar_buf.getvalue(),format=lzma.FORMAT_XZ,preset=9)
    zbuf=io.BytesIO()
    with zipfile.ZipFile(zbuf,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for p in allfiles:
            rel=p.relative_to(SOURCE).as_posix(); zi=zipfile.ZipInfo(rel,date_time=(1980,1,1,0,0,0)); zi.compress_type=zipfile.ZIP_DEFLATED; zi.create_system=3
            mode=0o755 if (p.stat().st_mode & 0o111) else 0o644; zi.external_attr=(mode & 0xFFFF)<<16
            zf.writestr(zi,p.read_bytes())
    checks_hash=sha(checks); bundle_hash=hashlib.sha256(bundle).hexdigest(); zip_hash=hashlib.sha256(zbuf.getvalue()).hexdigest()
    replace_const(ROOT/'.github/governance-source/VERIFY_SOURCE_IDENTITY.py','EXPECTED_BUNDLE_SHA256',bundle_hash)
    replace_const(ROOT/'.github/governance-source/VERIFY_SOURCE_IDENTITY.py','EXPECTED_SOURCE_ZIP_SHA256',zip_hash)
    for name,val in [('EXPECTED_CHECKSUMS_SHA256',checks_hash),('EXPECTED_SEMANTIC_CONTENT_HASH',semantic_hash),('EXPECTED_SOURCE_ZIP_SHA256',zip_hash),('EXPECTED_BUNDLE_SHA256',bundle_hash)]:
        replace_const(ROOT/'.github/governance-source/RUN_FULL_LINE_SYSTEM_GATE.py',name,val)
    return checks_hash,bundle_hash,zip_hash

def update_current_projection(semantic_hash, checks_hash, bundle_hash, zip_hash):
    p=ROOT/'governance/specifications/current/SPECIFICATION_MANIFEST.yaml'; m=load(p); oldpkg=(m.get('source_lineage') or {}).get('verified_package_filename'); oldhash=(m.get('source_lineage') or {}).get('verified_package_sha256')
    m['artifact_uid']=NEW_UID; m['display_version']=NEW_DISPLAY
    sl=m.setdefault('source_lineage',{}); sl.update({'verified_package_filename':NEW_PACKAGE,'verified_package_sha256':zip_hash,'predecessor_governance_uid':OLD_UID,'promotion_authorization_uid':AUTH_UID,'source_bytes_changed_by_this_successor':True,'source_identity_reused_only_because_source_bytes_are_unchanged':False,'deterministic_source_bundle_sha256':bundle_hash,'checksum_manifest_sha256':checks_hash,'semantic_authority_content_hash':semantic_hash,'verified_source_revision':NEW_SOURCE_REV,'predecessor_verified_package_filename':oldpkg,'predecessor_verified_package_sha256':oldhash,'post_promotion_projector_sync_authorization_uid':AUTH_UID})
    dump(p,m)

    p=ROOT/'governance/specifications/REGISTRY.yaml'; d=load(p); d['active_specification']['governance_uid']=NEW_UID; d['active_specification']['display_version']=NEW_DISPLAY; unique_extend(d['active_specification'].setdefault('aliases',[]),['basic-design-visual-integration-hardening']); d['immediate_predecessor']={'governance_uid':OLD_UID,'display_version':OLD_DISPLAY,'version_role':'SUPERSEDED_CURRENT_GOVERNANCE_HISTORY','status':'SUPERSEDED_HISTORY_ONLY_AFTER_BASIC_DESIGN_VISUAL_INTEGRATION_HARDENING'}; dump(p,d)

    p=ROOT/'GOVERNANCE_CURRENT.yaml'; d=load(p); d['active_governance_uid']=NEW_UID; d['display_version']=NEW_DISPLAY; d.setdefault('source_identity',{}).update({'verified_package_sha256':zip_hash,'deterministic_source_bundle_sha256':bundle_hash,'checksum_manifest_sha256':checks_hash,'semantic_authority_content_hash':semantic_hash,'verified_source_revision':NEW_SOURCE_REV,'source_bytes_changed_by_current_successor':True}); dump(p,d)

    p=ROOT/'governance/test/ACTIVE_STATE.yaml'; d=load(p); d['specification_uid']=NEW_UID; d['status']='ACTIVE_GOVERNANCE_BASIC_DESIGN_VISUAL_INTEGRATION_PROMOTED_REVALIDATION_REQUIRED'; d['next_action']='RUN_SUCCESSOR_EXACT_HEAD_VALIDATION_THEN_REEXECUTE_BASIC_DESIGN_WITH_COMPLETE_VISUAL_DESIGN'; d['current_primary_task_layer']='GOVERNANCE_MAINTENANCE'; d['current_primary_task_authorization_uid']=AUTH_UID; d['current_primary_task_product_stage_credit']=0
    tr=d.setdefault('governance_revision_transition',{}); tr.update({'predecessor_governance_uid':OLD_UID,'current_governance_uid':NEW_UID,'fresh_revalidation_required':True,'fresh_revalidation_scope':'BASIC_DESIGN_VISUAL_INTEGRATION_AND_AFFECTED_DESIGN_CONSUMERS','website_construction_remains_blocked':True,'deployment_remains_blocked':True})
    sr=d.setdefault('stage_execution_remediation_closure_protocol',{}); sr['frozen_specification_uid']=NEW_UID
    aw=d.setdefault('active_work_unit',{}); aw.update({'work_unit_uid':WORK_UNIT,'canonical_name':'BASIC_DESIGN_VISUAL_INTEGRATION_HARDENING','primary_task_layer':'GOVERNANCE_MAINTENANCE','canonical_owner':'.github/governance-source/active/source/12_DOCS/mother-spec/01_BLUEPRINT_DESIGN_GOVERNANCE.md','current_status':'PROMOTION_MATERIALIZED_EXACT_HEAD_REVALIDATION_REQUIRED','authorization_uid':AUTH_UID,'scope':['BASIC_DESIGN_INDEPENDENCE_FROM_IMPLEMENTATION','COMPLETE_VISUAL_DESIGN_IN_BASIC_DESIGN','VISUAL_AUTHORITY_INHERITANCE','VISUAL_STYLE_DEFINITION','HIGH_FIDELITY_MULTI_STATE_VISUALS','DESIGN_DOCUMENT_EMBEDDED_FIGURES','BASIC_DESIGN_FREEZE_COMPLETENESS'],'out_of_scope':['PRODUCT_AUTHORITY_CHANGE','IMPLEMENTATION_STANDARD_EXPANSION','SOURCE_CODE_CHANGE','CONSTRUCTION_DELTA','IMPLEMENTATION_HANDOFF','RUNTIME_TEST','DEPLOYMENT','PRODUCT_STAGE_CREDIT'],'product_stage_credit':0})
    rc=d.setdefault('resume_control',{}); rc.update({'current_resume_point':'BASIC_DESIGN_VISUAL_INTEGRATION_SUCCESSOR_PROMOTED_EXACT_HEAD_REVALIDATION_REQUIRED','current_work_unit_uid':WORK_UNIT,'current_owner':'.github/governance-source/active/source/12_DOCS/mother-spec/01_BLUEPRINT_DESIGN_GOVERNANCE.md','exact_next_action':'RUN_SUCCESSOR_EXACT_HEAD_VALIDATION_THEN_REEXECUTE_BASIC_DESIGN_WITH_COMPLETE_VISUAL_DESIGN'})
    dump(p,d)

    for rel in ['governance/test/CURRENT_EXECUTION_SCOPE_MANIFEST.yaml','governance/test/stage02/STAGE02_CURRENT_FINDINGS.yaml']:
        p=ROOT/rel
        if p.exists():
            d=load(p)
            if d.get('governance_uid')==OLD_UID: d['governance_uid']=NEW_UID
            if d.get('frozen_governance_uid')==OLD_UID: d['frozen_governance_uid']=NEW_UID
            if 'content_hash' in d: d['content_hash']=hobj(d)
            dump(p,d)

def validate_all():
    env=os.environ.copy(); env['PYTHONDONTWRITEBYTECODE']='1'; env['PYTHONPYCACHEPREFIX']='/tmp/acpos-v2211-pycache'
    cmds=[
      [sys.executable,str(SOURCE/'09_TESTS/governance/validate_section_registry.py')],
      [sys.executable,str(SOURCE/'09_TESTS/governance/validate_reference_semantics.py')],
      [sys.executable,str(SOURCE/'09_TESTS/governance/validate_product_neutral_entity_lifecycle.py')],
      [sys.executable,str(ROOT/'.github/governance-source/VERIFY_SOURCE_IDENTITY.py')],
      [sys.executable,str(ROOT/'governance/ci/governance_resolver.py')],
      [sys.executable,str(ROOT/'governance/ci/validate_governance_portability.py')],
      [sys.executable,str(ROOT/'governance/ci/validate_active_consumer_reference_integrity.py')],
      [sys.executable,str(ROOT/'governance/ci/validate_structured_mutation_safety.py')],
      [sys.executable,str(ROOT/'governance/ci/stress_test_governance_registry.py')],
      [sys.executable,str(ROOT/'governance/ci/validate_selected_execution_profile_integrity.py')],
      [sys.executable,str(ROOT/'governance/ci/stage_execution_engine.py'),'--definition-audit-all'],
      [sys.executable,str(ROOT/'governance/ci/test_stage_execution_engine.py')],
      [sys.executable,str(ROOT/'.github/governance-source/RUN_FULL_LINE_SYSTEM_GATE.py')],
    ]
    for cmd in cmds:
        cp=run(*cmd,check=False,env=env); print('$',' '.join(map(str,cmd))); print(cp.stdout[-6000:])
        if cp.returncode:
            print(cp.stderr[-9000:],file=sys.stderr); raise SystemExit(cp.returncode)

def main():
    cur=load(ROOT/'GOVERNANCE_CURRENT.yaml')
    if cur.get('active_governance_uid')!=OLD_UID: raise RuntimeError('UNEXPECTED_CURRENT_GOVERNANCE_UID:'+str(cur.get('active_governance_uid')))
    mutate_mother(); mutate_section_registry(); semantic_hash=mutate_lifecycle_and_refs(); mutate_invariants(); mutate_blueprint_acceptance_index(); mutate_validator(); mutate_current_components(); append_version_docs(); update_candidate_and_review()
    checks_hash,bundle_hash,zip_hash=refresh_source_identity(semantic_hash)
    update_current_projection(semantic_hash,checks_hash,bundle_hash,zip_hash)
    # remove one-shot workflow/helper/trigger before consumer validation and final commit
    for rel in ['.github/workflows/basic-design-visual-integration-promotion.yml','.github/governance-maintenance/promote_basic_design_visual_integration.py.gz','.github/governance-maintenance/BASIC_DESIGN_VISUAL_INTEGRATION_PROMOTE_TRIGGER']:
        p=ROOT/rel
        if p.exists(): p.unlink()
    validate_all()
    run('git','config','user.name','github-actions[bot]'); run('git','config','user.email','41898282+github-actions[bot]@users.noreply.github.com')
    run('git','add','-A')
    if run('git','diff','--cached','--quiet',check=False).returncode==0: raise RuntimeError('NO_PROMOTION_DELTA')
    msg='''feat(governance): separate basic design and complete visual design\n\nSpec-Change-Authorization: USR-DIRECTIVE-20260919-BASIC-DESIGN-VISUAL-INTEGRATION-R1\nSpec-Change-Scope: BASIC_DESIGN_COMPLETE_VISUAL_STYLE_INHERITANCE_EMBEDDED_FIGURES_AND_IMPLEMENTATION_DECOUPLING'''
    run('git','commit','-m',msg)
    run(sys.executable,str(ROOT/'governance/ci/specification_mutation_guard.py'))
    run('git','push','origin','HEAD:rebuild-v2.1.1')
    print(json.dumps({'status':'PROMOTION_PUSHED','head':run('git','rev-parse','HEAD').stdout.strip(),'new_uid':NEW_UID,'display_version':NEW_DISPLAY,'semantic_hash':semantic_hash,'zip_hash':zip_hash},indent=2))

if __name__=='__main__': main()
