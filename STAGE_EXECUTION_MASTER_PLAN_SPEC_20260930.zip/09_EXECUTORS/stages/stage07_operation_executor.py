#!/usr/bin/env python3
"""STAGE-07 per-operation executor (thin wrapper -> generic master-plan executor)."""
import os, sys
from pathlib import Path
os.environ.setdefault('STAGE_EXECUTOR_OWNER', 'STAGE_EXECUTION/STAGE-07/stage07_operation_executor.py')
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from stage_execution_generic_executor import main
if __name__ == '__main__':
    main()
