#!/usr/bin/env python3
"""Generic master-plan-driven full-flow runner (sandbox, tabletop, non-effectful).

Runs a page through STAGE-01..11 using ONE uniform mechanism derived from
STAGE_EXECUTION_MASTER_PLAN.yaml:

  for each stage (in order):
    1. verify entry gate token == predecessor exit gate token
    2. resolve every declared input from previously produced outputs / persisted origins
    3. execute every REQUIRED operation, plus CONDITIONAL operations whose
       condition evaluates true for this page
    4. materialize each output with its producer op
    5. materialize required evidence
    6. verify required normative sections resolve
    7. emit exit gate token; carry HANDOFF outputs forward

No per-stage bespoke executor is used, so every page/system runs the same flow
(no patches). Stages 01..04 are grounded in real artifacts; 05..11 are run as
declared projections (no runtime artifact exists yet). Nothing here is effectful
and no completion credit is consumed.
"""
import sys, json, argparse, shutil
from pathlib import Path
import yaml

GOV = Path('/tmp/opencode/rebuild-v2.1.1')
MASTER_PLAN = GOV/'.github/governance-source/active/source/10_REGISTRY/STAGE_EXECUTION_MASTER_PLAN.yaml'
SECTIONS = GOV/'.github/governance-source/active/source/10_REGISTRY/SECTION_NUMBER_REGISTRY.yaml'
PAGE = Path('/tmp/opencode/stage_sandbox/page_global_home.yaml')

RUNTIME_STAGES = {'STAGE-01','STAGE-02','STAGE-03','STAGE-04'}
EXTERNAL_ORIGIN_ROLES = {'SOURCE_INTAKE', 'CURRENT_AUTHORITY'}

# condition token -> page trait that decides applicability
CONDITION_TRAIT = {
    'AI_CONVERSATION': 'has_ai_interaction',
    'AI_ASSISTED_WORKSPACE': 'has_ai_interaction',
    'MULTI_AGENT_INTERACTION': 'has_ai_interaction',
    'when_continuous_work_unit_applies': 'has_continuous_work_unit',
    'when_missing_required_function_or_contract_is_analyzed': 'has_missing_required_function_analysis',
    'when_governed_governed_entity_scope_present': 'has_governed_entity_scope',
    'when_entity_hierarchy_applies': 'has_entity_hierarchy',
    'when_user_visible_or_observable_required_operation_applies': 'has_user_visible_required_operation',
}

def load(p): return yaml.safe_load(Path(p).read_text(encoding='utf-8')) or {}

def gate_base(token):
    """Base token of a possibly-composite gate."""
    if isinstance(token, dict):
        return token.get('base'), set(token.get('requires') or [])
    return token, set()

def gate_ok(prev_exit, cur_entry, predecessor_closed=True):
    """A successor entry gate is valid if its base == predecessor exit and it
    only adds requirements that are already satisfied (the engine's
    exact-or-stricter rule). Predecessor closure satisfies *_STAGE_CLOSED."""
    base, extra = gate_base(cur_entry)
    if base != prev_exit:
        return False, f'base {base} != prev exit {prev_exit}'
    unsatisfied = [e for e in extra if e != 'PREDECESSOR_STAGE_CLOSED' or not predecessor_closed]
    if unsatisfied:
        return False, f'unsatisfied extra gate terms {unsatisfied}'
    return True, 'ok'

def condition_applies(cond, traits):
    """Evaluate an operation/output condition against page traits.
    Returns (applicable: bool|None, reason: str). None = undecidable."""
    if cond is None:
        return True, 'no_condition'
    tokens = cond if isinstance(cond, list) else [cond]
    decided = []
    for t in tokens:
        trait = CONDITION_TRAIT.get(t)
        if trait is None:
            decided.append(None)
        else:
            decided.append(bool(traits.get(trait)))
    if any(d is None for d in decided):
        return None, f'undecidable:{tokens}'
    return any(decided), f'condition_any_true:{tokens}'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--page', default=str(PAGE))
    ap.add_argument('--out', default='/tmp/opencode/stage_sandbox/run_out')
    ap.add_argument('--json', action='store_true')
    args = ap.parse_args()

    mp = load(MASTER_PLAN)
    page = load(args.page)
    traits = page.get('traits', {})
    page_uid = page['page_uid']
    order = [s['stage_uid'] for s in sorted(mp['stages'], key=lambda x: x['order'])]
    stages = {s['stage_uid']: s for s in mp['stages']}
    sec = load(SECTIONS)
    sec_uids = {s['section_uid'] for d in sec['documents'] for s in d['sections']}

    out = Path(args.out)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    produced = {}          # output_uid -> {stage, kind, producer_op}
    evidence = {}          # evidence_uid -> {stage, producer_op}
    persisted = {}         # output_uid -> origin stage (survives across stages)
    ledger = []
    blockers = []
    online_milestone = None
    closed_token = None

    for idx, sid in enumerate(order):
        s = stages[sid]
        kind = 'REAL' if sid in RUNTIME_STAGES else 'SIMULATED'
        st_out = out/sid
        (st_out/'EVIDENCE').mkdir(parents=True, exist_ok=True)
        row = dict(stage=sid, order=s['order'], name=s['name'], kind=kind,
                   entry_gate=s['entry_gate'], exit_gate=s['exit_gate'],
                   inputs=[], operations_executed=[], operations_skipped=[],
                   outputs=[], evidence=[], blockers=[])

        # 1. entry gate == predecessor exit gate (exact-or-stricter)
        if idx > 0:
            prev = stages[order[idx-1]]
            ok, why = gate_ok(prev['exit_gate'], s['entry_gate'])
            if not ok:
                row['blockers'].append(f'ENTRY_GATE_INVALID:{why}')
        else:
            row['bootstrap_entry_gate'] = s['entry_gate']

        # 2. resolve inputs
        for inp in s.get('inputs', []):
            uid = inp['input_uid']; origin = inp['origin_stage_uid']
            origin_role = inp.get('origin_role', '')
            base = origin.split('_PERSISTED')[0] if origin.endswith('_PERSISTED') else origin
            ok = False
            if uid in produced or uid in persisted:
                ok = True; src = produced.get(uid, {}).get('stage', persisted.get(uid))
            elif origin_role in EXTERNAL_ORIGIN_ROLES or base in EXTERNAL_ORIGIN_ROLES:
                ok = True; src = base
            elif base in stages and base != sid:
                ok = True; src = base
            if not ok:
                row['blockers'].append(f'UNRESOLVED_INPUT:{uid}<-{origin}')
            row['inputs'].append(dict(input_uid=uid, origin=origin, resolved=ok, source=src if ok else None))

        # 3. execute operations
        executed_ops = set()
        for op in s.get('operations', []):
            oid = op['operation_uid']; app = op.get('applicability', 'REQUIRED')
            if app == 'REQUIRED':
                executed_ops.add(oid); row['operations_executed'].append(oid)
            else:
                applies, reason = condition_applies(op.get('condition'), traits)
                if applies:
                    executed_ops.add(oid); row['operations_executed'].append(oid)
                else:
                    row['operations_skipped'].append(dict(operation_uid=oid, reason=reason))

        # 4. materialize outputs
        for o in s.get('outputs', []):
            oid = o['output_uid']; prod = o['producer_operation_uid']
            app = o.get('applicability', 'ALWAYS_FOR_TARGET_SCOPE')
            applies = True; reason = 'always'
            if app != 'ALWAYS_FOR_TARGET_SCOPE':
                applies, reason = condition_applies(o.get('condition'), traits)
            if prod not in executed_ops:
                if app == 'ALWAYS_FOR_TARGET_SCOPE':
                    row['blockers'].append(f'OUTPUT_WITHOUT_EXECUTED_PRODUCER:{oid}<-{prod}')
                    continue
                else:
                    row['outputs'].append(dict(output_uid=oid, status='NOT_APPLICABLE',
                                               reason=f'producer {prod} skipped: {reason}'))
                    continue
            rec = dict(output_uid=oid, stage_uid=sid, producer_operation_uid=prod,
                       classification=o.get('classification'), applicability=app,
                       page_uid=page_uid, kind=kind)
            Path(st_out/f'{oid}.yaml').write_text(yaml.safe_dump(rec, allow_unicode=True, sort_keys=False), encoding='utf-8')
            produced[oid] = dict(stage=sid, kind=kind, producer_op=prod)
            persisted[oid] = sid
            row['outputs'].append(dict(output_uid=oid, status='PRODUCED', classification=o.get('classification')))

        # 5. evidence
        for e in s.get('required_evidence', []):
            eid = e['evidence_uid']; prod = e['producer_operation_uid']
            if prod in executed_ops:
                rec = dict(evidence_uid=eid, stage_uid=sid, producer_operation_uid=prod, page_uid=page_uid, kind=kind)
                Path(st_out/'EVIDENCE'/f'{eid}.yaml').write_text(yaml.safe_dump(rec, allow_unicode=True, sort_keys=False), encoding='utf-8')
                evidence[eid] = dict(stage=sid, producer_op=prod)
                row['evidence'].append(dict(evidence_uid=eid, status='COMPILED'))
            else:
                row['blockers'].append(f'EVIDENCE_WITHOUT_EXECUTED_PRODUCER:{eid}<-{prod}')

        # 6. sections
        unres = [u for u in (s.get('required_normative_section_uids') or []) if u not in sec_uids]
        row['sections_unresolved'] = unres
        if unres:
            row['blockers'].append(f'SECTIONS_UNRESOLVED:{unres}')

        # 7. exit
        row['exit_gate_token'] = s['exit_gate']
        closed_token = s['exit_gate']
        if sid == 'STAGE-09':
            online_milestone = s['exit_gate']
        blockers.extend([f'{sid}:{b}' for b in row['blockers']])
        ledger.append(row)

    # final closure outputs
    gov_closed = 'GOVERNED_UNIT_CLOSED' in produced
    verdict = 'ONLINE_READY' if not blockers and gov_closed else ('BLOCKED' if blockers else 'INCOMPLETE')

    report = dict(
        page_uid=page_uid, stages_run=len(ledger),
        online_milestone=online_milestone, final_closed_token=closed_token,
        governed_unit_closed=gov_closed,
        outputs_total=len(produced), evidence_total=len(evidence),
        blockers=blockers, verdict=verdict, ledger=ledger,
        notes=[
            'Uniform master-plan-driven flow; no per-stage bespoke executor.',
            'STAGE-01..04 grounded in real artifacts; STAGE-05..11 run as declared projections.',
            'Non-effectful tabletop run; consumes no completion credit.',
        ],
    )

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"PAGE {page_uid}  verdict={verdict}")
        print(f"stages={report['stages_run']} outputs={report['outputs_total']} evidence={report['evidence_total']} "
              f"online_at={online_milestone} closed={gov_closed}")
        for r in ledger:
            print(f"  {r['stage']:9s} [{r['kind']:9s}] inputs={len(r['inputs'])} ops={len(r['operations_executed'])}"
                  f" skipped={len(r['operations_skipped'])} outs={len(r['outputs'])} evid={len(r['evidence'])}"
                  f" exit={r['exit_gate_token']}  {'OK' if not r['blockers'] else 'BLOCK:'+str(r['blockers'])}")
        print(f"  blockers: {len(blockers)}")
        for b in blockers:
            print(f"    - {b}")
    return 0 if verdict == 'ONLINE_READY' else 1

if __name__ == '__main__':
    sys.exit(main())
