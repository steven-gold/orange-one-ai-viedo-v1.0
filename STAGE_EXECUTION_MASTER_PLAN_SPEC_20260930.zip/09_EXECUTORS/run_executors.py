#!/usr/bin/env python3
"""Drive the STAGE-05..11 per-stage executors over every declared operation,
using the exact engine command form, inside a sandbox execution root.

Proves the generic executor protocol works for the previously-missing stages.
Read-only w.r.t. governance; writes only under the sandbox exec root.
"""
import json, shutil, subprocess, sys
from pathlib import Path
import yaml

GOV = Path('/tmp/opencode/rebuild-v2.1.1')
PLAN = GOV/'.github/governance-source/active/source/10_REGISTRY/STAGE_EXECUTION_MASTER_PLAN.yaml'
ROOT = Path('/tmp/opencode/stage_sandbox/exec_root')
STAGES = ['STAGE-01','STAGE-02','STAGE-03','STAGE-04','STAGE-05','STAGE-06','STAGE-07','STAGE-08','STAGE-09','STAGE-10','STAGE-11']

def load(p): return yaml.safe_load(Path(p).read_text(encoding='utf-8')) or {}

def main():
    plan = load(PLAN)
    if ROOT.exists():
        shutil.rmtree(ROOT)
    (ROOT/'STAGE_EXECUTION').mkdir(parents=True)
    # expose governance source so the executor resolves the master plan
    (ROOT/'.github').symlink_to('/workspace/.github')
    results = []
    for sid in STAGES:
        st = next(s for s in plan['stages'] if s['stage_uid']==sid)
        wu_rel = f'STAGE_EXECUTION/{sid}/WU-{sid}-GLOBAL-HOME-SHELL-NAVIGATION-001/WORK_UNIT.yaml'
        wrapper = Path('/workspace')/f'STAGE_EXECUTION/{sid}/stage{sid.split("-")[1]}_operation_executor.py'
        stage_ops = [o['operation_uid'] for o in st['operations']]
        for op in stage_ops:
            cmd = [sys.executable, str(wrapper), '--stage', sid, '--operation', op,
                   '--work-unit', wu_rel, '--product-root', str(ROOT)]
            proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
            receipt = ROOT/f'STAGE_EXECUTION/{sid}/WU-{sid}-GLOBAL-HOME-SHELL-NAVIGATION-001/EVIDENCE/OPERATION_RECEIPTS/{op}.yaml'
            ok = proc.returncode==0 and receipt.is_file()
            results.append(dict(stage=sid, operation=op, rc=proc.returncode, receipt=receipt.is_file(),
                                out=(proc.stdout or proc.stderr or '').strip()[:120]))
    total = len(results)
    ok = sum(1 for r in results if r['rc']==0 and r['receipt'])
    print(f'executors drove {total} operations across {len(STAGES)} stages; ok={ok}')
    for sid in STAGES:
        n = sum(1 for r in results if r['stage']==sid)
        nok = sum(1 for r in results if r['stage']==sid and r['rc']==0 and r['receipt'])
        print(f'  {sid}: {nok}/{n} operations -> receipts')
    bad = [r for r in results if r['rc']!=0 or not r['receipt']]
    for r in bad[:10]:
        print('  FAIL', r['stage'], r['operation'], r['rc'], r['out'])
    Path('/tmp/opencode/stage_sandbox/executor_drive_result.json').write_text(json.dumps(dict(total=total, ok=ok, results=results), ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if ok==total else 1

if __name__=='__main__':
    sys.exit(main())
