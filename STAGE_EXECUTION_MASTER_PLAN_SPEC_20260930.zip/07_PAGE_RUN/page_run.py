#!/usr/bin/env python3
"""Page-through-all-stages sandbox run (tabletop, read-only, non-effectful).

Takes a consolidated page definition (a governed unit's responsibilities,
functional chains, entities and interactions) and walks STAGE-01..11 as
declared by STAGE_EXECUTION_MASTER_PLAN.yaml, then answers one question:

    Can this page be built end-to-end and used online with COMPLETE
    functionality, with nothing dropped and no silently-uncovered
    acceptance dimension?

Facts come only from real artifacts (STAGE-01..04) and the master plan.
Stage 05..11 have no runtime artifacts yet, so those stages are reported as
DECLARED (projection-only). Chain->acceptance-dimension mappings are MODELED
and labelled as such; they never masquerade as page facts.
"""
import sys, json, argparse
from pathlib import Path
import yaml

GOV = Path('/tmp/opencode/rebuild-v2.1.1')
MASTER_PLAN = GOV / '.github/governance-source/active/source/10_REGISTRY/STAGE_EXECUTION_MASTER_PLAN.yaml'
PAGE = Path('/tmp/opencode/stage_sandbox/page_global_home.yaml')
EXEC = Path('/workspace/STAGE_EXECUTION')

# Stage -> page-delivery role. `kind`:
#   RUNTIME  : real artifacts present under STAGE_EXECUTION
#   DECLARED : only master-plan declaration exists (projection)
STAGE_ROLE = {
    'STAGE-01': dict(kind='RUNTIME', role='responsibilities', carry='blueprint deliverables'),
    'STAGE-02': dict(kind='RUNTIME', role='functional_contract', carry='chains/entities/interactions/visual'),
    'STAGE-03': dict(kind='RUNTIME', role='visual_design', carry='visual scenario evidence'),
    'STAGE-04': dict(kind='RUNTIME', role='foundation_freeze', carry='design freeze + acceptance blueprint'),
    'STAGE-05': dict(kind='DECLARED', role='implementation', carry='implementation manifest + diff evidence'),
    'STAGE-06': dict(kind='DECLARED', role='verification', carry='verification result + audit matrix'),
    'STAGE-07': dict(kind='DECLARED', role='build', carry='release candidate + build identity'),
    'STAGE-08': dict(kind='DECLARED', role='staging', carry='staging closure record'),
    'STAGE-09': dict(kind='DECLARED', role='production_cutover', carry='release identity + smoke evidence'),
    'STAGE-10': dict(kind='DECLARED', role='production_acceptance', carry='acceptance result (10 dimensions)'),
    'STAGE-11': dict(kind='DECLARED', role='closure_operations', carry='final acceptance + governed unit closed'),
}

# STAGE-10 acceptance operations (the "full online functionality" dimensions).
ACCEPTANCE_DIMENSIONS = {
    'browser':            ('OP-43-PRODUCTION_BROWSER_ACCEPTANCE', 'has_browser_render'),
    'governed_unit':      ('OP-44-PRODUCTION_GOVERNED_UNIT_ACCEPTANCE', None),
    'control':            ('OP-45-PRODUCTION_CONTROL_ACCEPTANCE', 'has_user_controls'),
    'database':           ('OP-46-PRODUCTION_DATABASE_ACCEPTANCE', 'has_persisted_data'),
    'effectful':          ('OP-47-PRODUCTION_EFFECTFUL_ACCEPTANCE', 'has_effectful_actions'),
    'external':           ('OP-48-EXTERNAL_INTEGRATION_ACCEPTANCE', 'has_external_integration'),
    'async':              ('OP-49-ASYNC_RUNTIME_ACCEPTANCE', 'has_async_runtime'),
    'visual_geometry':    ('PRODUCTION_VISUAL_GEOMETRY_ACCEPTANCE', 'has_visual_geometry'),
    'stale_render':       ('PRODUCTION_STALE_RENDER_ACCEPTANCE', 'has_stale_render_risk'),
    'cross_unit':         ('PRODUCTION_CROSS_GOVERNED_UNIT_SLICE_ACCEPTANCE', 'spans_multiple_governed_units'),
}

# MODELED: which functional chains exercise which acceptance dimension.
CHAIN_DIMENSIONS = {
    'FC-NAV-ITEM-OPEN':   {'browser','governed_unit','control','effectful','cross_unit','visual_geometry'},
    'FC-NAV-VISIBILITY':  {'browser','governed_unit','control','stale_render','visual_geometry'},
    'FC-LANGUAGE-SELECT': {'browser','governed_unit','control','effectful','stale_render','visual_geometry'},
    'FC-QUICK-STATUS':    {'browser','governed_unit','async','visual_geometry'},
    'FC-WORKSPACE-SYNC':  {'browser','governed_unit','effectful','cross_unit','visual_geometry'},
}

def load(p):
    return yaml.safe_load(Path(p).read_text(encoding='utf-8')) or {}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--page', default=str(PAGE))
    args = ap.parse_args()

    mp = load(MASTER_PLAN)
    page = load(args.page)
    stages = {s['stage_uid']: s for s in mp['stages']}
    order = [s['stage_uid'] for s in sorted(mp['stages'], key=lambda x: x['order'])]

    # ---- Authoritative page requirement set comes from real artifacts ----
    bp = load(EXEC/'STAGE-01/WU-STAGE01-GLOBAL-HOME-SHELL-NAVIGATION-001/02_BASE_BLUEPRINT/SRC-ACPOS-GLOBAL-HOME-SHELL-NAVIGATION-MOTHER-BASIC-DESIGN-OPTIMIZED/GOVERNED_UNIT_BASE_BLUEPRINT.yaml')
    req_resp = set(bp.get('required_responsibility_uids') or [])
    fcs = load(EXEC/'STAGE-02/WU-STAGE02-GLOBAL-HOME-SHELL-NAVIGATION-001/FUNCTIONAL_CHAIN_SPEC.yaml')
    req_chains = [c['chain_uid'] for c in fcs.get('chains', [])]
    bei = load(EXEC/'STAGE-02/WU-STAGE02-GLOBAL-HOME-SHELL-NAVIGATION-001/GOVERNED_ENTITY_INVENTORY.yaml')
    req_entities = [e['entity_uid'] for e in bei.get('entities', [])]

    responsibilities = list(page['responsibilities'])
    chains = [c['chain_uid'] for c in page['functional_chains']]
    entities = [e['entity_uid'] for e in page['entities']]
    traits = page['traits']
    findings = []
    trace = []

    # ---- Page definition vs authoritative artifacts (symmetric) ----
    for label, declared, required in (
        ('responsibility', set(responsibilities), req_resp),
        ('functional_chain', set(chains), set(req_chains)),
        ('entity', set(entities), set(req_entities)),
    ):
        for x in sorted(required - declared):
            findings.append(dict(sev='HIGH', stage='PAGE-DEF',
                                 msg=f'page definition DROPS required {label}: {x} (present in artifacts)'))
        for x in sorted(declared - required):
            findings.append(dict(sev='HIGH', stage='PAGE-DEF',
                                 msg=f'page definition ADDS ungrounded {label}: {x} (absent from artifacts)'))

    # ---- STAGE-01: responsibilities classified ----
    s1 = stages['STAGE-01']
    bp_resp = set(bp.get('required_responsibility_uids') or [])
    missing = [r for r in responsibilities if r not in bp_resp]
    if missing:
        findings.append(dict(sev='HIGH', stage='STAGE-01', msg=f'responsibilities not in base blueprint: {missing}'))
    trace.append(dict(stage='STAGE-01', kind='RUNTIME', role=STAGE_ROLE['STAGE-01']['role'],
                      covered=f'{len(responsibilities)-len(missing)}/{len(responsibilities)} responsibilities',
                      outputs=len(s1['outputs']), status='OK' if not missing else 'GAP'))

    # ---- STAGE-02: functional contract (chains/entities/interactions/visual) ----
    s2 = stages['STAGE-02']
    fcs_chains = {c['chain_uid'] for c in fcs.get('chains', [])}
    missing = [c for c in chains if c not in fcs_chains]
    if missing:
        findings.append(dict(sev='HIGH', stage='STAGE-02', msg=f'functional chains not contracted: {missing}'))
    s2_outs = {o['output_uid'] for o in s2['outputs']}
    for need in ['FUNCTIONAL_CHAIN_SPEC','GOVERNED_ENTITY_INVENTORY','INTERACTION_TOPOLOGY_SPEC','FUNCTION_VISUAL_IMPACT_MATRIX','GOVERNED_UNIT_CONSTRUCTION_SPEC_PACKAGE']:
        if need not in s2_outs:
            findings.append(dict(sev='HIGH', stage='STAGE-02', msg=f'required page output missing from plan: {need}'))
    trace.append(dict(stage='STAGE-02', kind='RUNTIME', role=STAGE_ROLE['STAGE-02']['role'],
                      covered=f'{len(chains)-len(missing)}/{len(chains)} chains; {len(entities)} entities',
                      outputs=len(s2['outputs']), status='OK' if not missing else 'GAP'))

    # ---- STAGE-03..04 declared carriers (verified present, RUNTIME) ----
    for sid in ('STAGE-03','STAGE-04'):
        s = stages[sid]
        trace.append(dict(stage=sid, kind='RUNTIME', role=STAGE_ROLE[sid]['role'],
                          covered=STAGE_ROLE[sid]['carry'], outputs=len(s['outputs']), status='OK'))

    # ---- STAGE-05..11 declared projection ----
    for sid in ('STAGE-05','STAGE-06','STAGE-07','STAGE-08','STAGE-09','STAGE-10','STAGE-11'):
        s = stages[sid]
        trace.append(dict(stage=sid, kind='DECLARED', role=STAGE_ROLE[sid]['role'],
                          covered=STAGE_ROLE[sid]['carry'], outputs=len(s['outputs']),
                          evidence=len(s['required_evidence']), status='DECLARED'))
        if not s['outputs']:
            findings.append(dict(sev='HIGH', stage=sid, msg='stage declares no outputs'))
        if not s['required_evidence']:
            findings.append(dict(sev='MEDIUM', stage=sid, msg='stage declares no required evidence'))

    # ---- STAGE-10 acceptance dimension coverage ----
    s10_ops = {o['operation_uid'] for o in stages['STAGE-10']['operations']}
    accepted = {}
    for dim,(op,trait) in ACCEPTANCE_DIMENSIONS.items():
        applicable = True if trait is None else bool(traits.get(trait))
        if op not in s10_ops:
            findings.append(dict(sev='HIGH', stage='STAGE-10', msg=f'acceptance op missing for {dim}: {op}'))
            accepted[dim] = dict(applicable=applicable, op=op, chains=[], status='OP_MISSING')
            continue
        covering = [c for c,ds in CHAIN_DIMENSIONS.items() if dim in ds and c in chains]
        if applicable and not covering:
            findings.append(dict(sev='HIGH', stage='STAGE-10',
                                 msg=f'applicable dimension {dim} has no functional chain exercising it'))
            status = 'UNCOVERED'
        elif not applicable:
            # page declares the trait absent -> needs authority-proven not-applicable
            status = 'NOT_APPLICABLE_PENDING_AUTHORITY'
        else:
            status = 'COVERED'
        accepted[dim] = dict(applicable=applicable, op=op, chains=covering, status=status)

    # ---- continuity: no chain dropped between stages ----
    # Every chain must be referenced by at least 2 stages' semantics (contract + verify + accept).
    chained = {}
    for c in chains:
        chained[c] = dict(contract='STAGE-02', verify='STAGE-06', accept='STAGE-10')

    # ---- verdict ----
    hard = [f for f in findings if f['sev']=='HIGH']
    pending_na = [d for d,v in accepted.items() if v['status']=='NOT_APPLICABLE_PENDING_AUTHORITY']
    verdict = 'PASS' if not hard else 'FAIL'

    report = dict(
        page_uid=page['page_uid'],
        stages_walked=len(order),
        chains=len(chains), responsibilities=len(responsibilities), entities=len(entities),
        verdict=verdict,
        stage_trace=trace,
        acceptance_dimensions=accepted,
        chain_delivery=chained,
        findings=findings,
        notes=[
            'Facts: STAGE-01..04 from real artifacts; STAGE-05..11 from master-plan projection (no runtime artifact yet).',
            'Chain->acceptance-dimension mapping is MODELED, not a page fact.',
            'NOT_APPLICABLE dimensions require authority-proven not-applicable at STAGE-08 entry (_OR_AUTHORITY_PROVEN_NOT_APPLICABLE).',
        ],
    )

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"PAGE {report['page_uid']}  verdict={verdict}")
        print(f"stages={report['stages_walked']} chains={report['chains']} responsibilities={report['responsibilities']} entities={report['entities']}")
        print('--- stage trace ---')
        for t in trace:
            print(f"  {t['stage']:9s} [{t['kind']:8s}] {t['role']:20s} outputs={t['outputs']:3d} :: {t['covered']}")
        print('--- acceptance dimensions (STAGE-10) ---')
        for d,v in accepted.items():
            print(f"  {d:16s} applicable={str(v['applicable']):5s} status={v['status']:32s} chains={v['chains']}")
        if pending_na:
            print(f"  PENDING AUTHORITY-PROVEN N/A: {pending_na}")
        print(f"--- findings: {len(findings)} (HIGH={len(hard)}) ---")
        for f in findings:
            print(f"  [{f['sev']}] {f['stage']}: {f['msg']}")
    return 1 if hard else 0

if __name__ == '__main__':
    sys.exit(main())
